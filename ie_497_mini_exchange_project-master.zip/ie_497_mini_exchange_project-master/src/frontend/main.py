from datetime import datetime as dt
from os import path

import dash
import dash_core_components as dcc
import dash_daq as daq
import dash_html_components as html
import dash_table
import pandas as pd
import plotly.graph_objs as go
from dash.dependencies import Input, Output, State

import src.frontend.efunctions as efunctions
import src.frontend.retrieve as retrieve

app = dash.Dash(__name__)
app.title = 'Trade Platform'

last_order = 'sample click'
today = dt.now()


def displayPage():
  main_layout = html.Div(style={'backgroundColor': '#ffffff'}, children=[

      dcc.ConfirmDialog(
          id='confirm',
          message='Submit this order?',
      ),
      html.Div([
          dcc.Dropdown(
               id='dropdown',
               options=[
                  {'label': 'Microsoft', 'value': 'MSFT'},
                  {'label': 'Amazon', 'value': 'AMZN'},
                  {'label': 'Uber', 'value': 'UBER'}
               ],
               value='MSFT', clearable=False),
      ], style={'margin-top': '6'}),

      html.Div([
          dcc.Checklist(
              id='checklist',
              options=[
                  {'label': 'Buy Orders', 'value': 'buy'},
                  {'label': 'Sell Orders', 'value': 'sell'},
                  {'label': 'Trades', 'value': 'trades'}
              ],
              values=['buy', 'sell', 'trades'],
              labelStyle={'display': 'inline-block'}
          ),
      ], style={'margin-top': '4', 'margin-bottom': '20'}),



      dcc.Tabs(id="tabs", children=[
          dcc.Tab(label='Order Book', children=[
                  # The main graph

                  html.Div([
                      dcc.Graph(
                        id='main-graph'),
                      dcc.Interval(
                          id='graph-update',
                          interval=15*1000,
                          n_intervals=0
                      )

                  ]),





                  html.Div([
                      dcc.RangeSlider(
                          id='slider',
                          min=0,
                          max=10,
                          step=0.5,
                          value=[5])
                  ], style={'margin-top': '18', 'margin-bottom': '54', 'margin-left': '22', 'margin-right': '22'}),


                  html.Div([
                      dcc.RadioItems(
                          id='radio',
                          options=[
                              {'label': 'Buy Order', 'value': 'Buy Order'},
                              {'label': 'Sell Order', 'value': 'Sell Order'}

                          ],
                          style={'margin-right': '20', 'margin-top': '-4'},
                          value='Buy Order',
                          labelStyle={}
                      ),
                      dcc.Input(id='Price', type='number', placeholder='Price', style={
                                'height': '42', 'width': '135', 'margin-right': '16'}),
                      daq.BooleanSwitch(
                          id='switch',
                          on=False,
                          label='Market Value',
                          labelPosition='top',
                          style={'margin-right': '16', 'margin-top': '-23'}
                      ),
                      dcc.Input(id='Volume', type='number', placeholder='Volume', style={
                                'height': '42', 'width': '135', 'margin-right': '15'}),


                      html.Button('Submit', id='button',
                                  style={'height': '42'}),

                  ], style={'margin-bottom': '40', 'display': 'flex', 'justify-content': 'center'}),


                  html.Div([
                      html.Div([

                          html.H1(id='labelCont', children='Buy Orders',
                                  style={'textAlign': 'center', 'border-style': 'solid', 'margin-left': '37%', 'margin-right': '37%', 'padding': '2px',
                                         'font-family': 'Andale Mono, monospace', 'color': 'black', 'font-size': 23, 'font-weight': 'normal'}),
                          dash_table.DataTable(
                           id='table',
                           #style_cell={'padding': '5px'},
                           style_header={
                               'fontWeight': 'bold'
                           },
                           style_cell={'textAlign': 'center'},
                           style_cell_conditional=[
                               {
                                   'if': {'row_index': 'odd'},
                                   'backgroundColor': '#8dbbdd'
                               }],

                           style_table={
                               'maxHeight': '600',
                               'overflowY': 'scroll',
                               'border': 'thin black solid'
                           },
                           columns=[
                               {"name": 'ID', "id": 'ID'},
                               {"name": 'Price ($)', "id": 'Price'},
                               {"name": 'Volume', "id": 'Volume'},
                           ],
                           n_fixed_rows=1,

                           ),  dcc.Interval(
                              id='btable-update',
                              interval=15*1000,
                              n_intervals=0
                          )], className="six columns",  style={'margin-right': '10', 'margin-left': '10'}),

                      html.Div([
                          html.H1(id='sell_label', children='Sell Orders',
                                  style={'textAlign': 'center', 'border-style': 'solid', 'margin-left': '37%', 'margin-right': '37%', 'padding': '2px',
                                         'font-family': 'Andale Mono, monospace', 'color': 'black', 'font-size': 23, 'font-weight': 'normal'}),
                          dash_table.DataTable(
                              id='stable',
                              #style_cell={'padding': '5px'},
                              style_header={
                               'fontWeight': 'bold'
                               },
                              style_cell={'textAlign': 'center'},
                              style_cell_conditional=[
                                  {
                                      'if': {'row_index': 'odd'},
                                      'backgroundColor': '#fccc76'
                                  }],

                              style_table={
                                  'maxHeight': '600',
                                  'overflowY': 'scroll',
                                  'border': 'thin black solid'
                              },
                              columns=[
                                  {"name": 'ID', "id": 'ID'},
                                  {"name": 'Price ($)', "id": 'Price'},
                                  {"name": 'Volume', "id": 'Volume'},
                              ],
                              n_fixed_rows=1,

                          ),
                          dcc.Interval(
                              id='stable-update',
                              interval=15*1000,
                              n_intervals=0
                          )], className="six columns", style={'margin-left': '10', 'margin-right': '10'})
                  ], className="row", style={'margin-top': '30px', 'margin-bottom': '20'})
                  ], className='custom-tab',
                  selected_className='custom-tab--selected'),
          dcc.Tab(label='Trades', className='custom-tab',
                  selected_className='custom-tab--selected',
                  children=[
                        html.Div([
                            html.Div([
                                dcc.Graph(
                                    id='trade-graph'),
                                dcc.Interval(
                                    id='tgraph-update',
                                    interval=15*1000,
                                    n_intervals=0
                                )
                            ], style={'width': '100%'}),

                            # The Graduated bar on the side
                            html.Div([
                                daq.GraduatedBar(
                                    id='gbar',
                                    vertical=True,
                                    color="#78ceed",
                                    max=10,
                                    value=5,
                                    size=230,
                                ),
                                dcc.Interval(
                                    id='bar-update',
                                    interval=15*1000,
                                    n_intervals=0
                                )
                            ], style={'margin-top': '140', 'margin-left': '-43'})

                        ], style={'display': 'flex', 'flex-direction': 'row'}),

                      html.Div([
                          dcc.RangeSlider(
                              id='tslider',
                              min=0,
                              max=10,
                              step=0.5,
                              value=[5, 10])
                      ], style={'margin-top': '18', 'margin-bottom': '40', 'margin-left': '26', 'margin-right': '26'}),
                      html.Div([
                          dash_table.DataTable(
                              id='hoverTable',
                              style_header={
                                  'fontWeight': 'bold'
                              },
                              style_cell={'textAlign': 'center',
                                          # 'minWidth': '25%', 'width': '25%', 'maxWidth': '25%'
                                          },
                              style_table={
                                  'border': 'thin lightgray solid'
                              },
                              style_cell_conditional=[
                                  {
                                      'if': {'column_id': 'Time'},
                                      'width': '34%',
                                  },

                                  {
                                      'if': {'column_id': 'ID'},
                                      'width': '16%',
                                  },

                                  {
                                      'if': {'column_id': 'Price'},
                                      'width': '25%',
                                  },

                                  {
                                      'if': {'column_id': 'Volume'},
                                      'width': '25%',
                                  }

                              ],
                              columns=[
                                  {"name": 'ID', "id": 'ID'},
                                  {"name": 'Time', "id": 'Time'},
                                  {"name": 'Price ($)', "id": 'Price'},
                                  {"name": 'Volume', "id": 'Volume'},
                              ],

                          ),
                          dcc.Interval(
                              id='hover-update',
                              interval=15*1000,
                              n_intervals=0
                          )



                      ], style={'margin-top': '1', 'margin-bottom': '39', 'margin-left': '3.9%', 'margin-right': '3.9%'}),

                      html.H1(children='Market Transactions',
                              style={'textAlign': 'center', 'border-style': 'solid', 'margin-left': '40%', 'margin-right': '40%', 'padding': '2px',
                                       'font-family': 'Andale Mono, monospace', 'color': '#0E0D85', 'font-size': 23, 'font-weight': 'normal'}),

                      html.Div([
                          dash_table.DataTable(
                              id='ttable',
                              #style_cell={'padding': '5px'},
                              style_header={
                                  'fontWeight': 'bold'
                              },
                              style_cell={'textAlign': 'center',
                                          'minWidth': '25%', 'width': '25%', 'maxWidth': '25%',

                                          },
                              style_cell_conditional=[
                                  {
                                      'if': {'row_index': 'odd'},
                                      'backgroundColor': '#ffd3d3'
                                  }],

                              style_table={
                                  'maxHeight': '700',
                                  'overflowY': 'scroll',
                                  'border': 'thin #0E0D85 solid'

                              },
                              columns=[
                                  {"name": 'ID', "id": 'ID'},
                                  {"name": 'Time', "id": 'Time'},
                                  {"name": 'Price ($)', "id": 'Price'},
                                  {"name": 'Volume', "id": 'Volume'},
                              ],
                              n_fixed_rows=1
                          ),
                          dcc.Interval(
                              id='ttable-update',
                              interval=15*1000,
                              n_intervals=0
                          )



                      ], style={'margin-bottom': '20', 'margin-left': '7.7%', 'margin-right': '7.7%'})

                  ])
      ]),
      html.Div(id='placeholder', style={'display': 'none'})




  ])
  return main_layout


app.layout = displayPage


@app.callback(
    Output('main-graph', 'figure'),
    [Input('checklist', 'values'), Input('dropdown', 'value'),  Input('slider', 'value'), Input('graph-update', 'n_intervals')])
def update(selector, tab, slider, n):
  return efunctions.graph(selector, tab, slider)


@app.callback(
    Output('trade-graph', 'figure'),
    [Input('checklist', 'values'), Input('dropdown', 'value'),  Input('tslider', 'value'), Input('tgraph-update', 'n_intervals')])
def tupdate(selector, tab, tslider, n):
  return efunctions.tgraph(selector, tab, tslider)


@app.callback(
    Output('table', 'data'),
    [Input('checklist', 'values'), Input('dropdown', 'value'), Input('btable-update', 'n_intervals')])
def table(selector, tab, n):
  return retrieve.table(selector, tab)


@app.callback(
    Output('stable', 'data'),
    [Input('checklist', 'values'), Input('dropdown', 'value'), Input('stable-update', 'n_intervals')])
def table(selector, tab, n):
  return retrieve.stable(selector, tab)


@app.callback(
    Output('ttable', 'data'),
    [Input('checklist', 'values'), Input('dropdown', 'value'), Input('ttable-update', 'n_intervals')])
def ttable(selector, tab, n):
  return retrieve.ttable(selector, tab)


@app.callback(
    Output('hoverTable', 'data'),
    [Input('checklist', 'values'), Input('dropdown', 'value'), Input('trade-graph', 'hoverData'), Input('hover-update', 'n_intervals')])
def hovertable(selector, tab, hover, n):
  return retrieve.hovertable(selector, tab, hover)


@app.callback(
    Output('confirm', 'displayed'),
    [Input('button', 'n_clicks')],
    [State('Price', 'value'), State('Volume', 'value'), State('radio', 'value'), State('dropdown', 'value')])
def track(button, price, vol, type, market):
  global last_order
  if button != None:  # If a point is clicked
    last_order = str(today) + ' | ' + type + ' for ' + market + \
        ' | Price: $' + str(price) + ' | Volume: ' + str(vol)
    return True  # Display the notification
  return False

@app.callback(Output('placeholder', 'children'),
              [Input('confirm', 'cancel_n_clicks_timestamp'), Input('confirm', 'submit_n_clicks_timestamp'), Input('confirm', 'submit_n_clicks')])
def track_point(last_canceled, last_submitted, num_clicks):
  orders_file_path = path.join(
      path.dirname(__file__), 'resources', 'orders.txt')

  if last_canceled != None and last_submitted != None:
    if last_submitted > last_canceled:  # if the user last clicked sumbit
      f = open(orders_file_path, "a")
      f.write(last_order)
      f.write('\n\n')
      f.close()

  elif num_clicks != None:
    f = open(orders_file_path, "a")
    f.write(last_order)
    f.write('\n\n')
    f.close()
  return 0


@app.callback(
    Output('Price', 'value'),
    [Input('switch', 'on')],
    [State('dropdown', 'value')])
def change_price(on, tab):
  if on == True:
    return retrieve.getPrice(tab)
  else:
    return ''


@app.callback(
    dash.dependencies.Output('gbar', 'value'),
    [Input('trade-graph', 'hoverData'), Input('bar-update', 'n_intervals')],
    [State('dropdown', 'value')])
def update_output(hover, n, market):
  return retrieve.bar(hover, market)


app.css.append_css({
    'external_url': 'https://codepen.io/chriddyp/pen/bWLwgP.css'
})


if __name__ == '__main__':
  app.run_server(debug=True)
