import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import plotly.graph_objs as go
from dash.dependencies import Input, Output

import src.frontend.retrieve as retrieve


def graph(selector, tab, slider):
  data = []
  title = tab
  data.clear()
  if 'buy' in selector:
    data.append({'x': retrieve.retrieve(tab, slider)['x'],
                 'y': retrieve.retrieve(tab, slider)['y'], 'type': 'line', 'name': 'Buys', 'fill': 'tozeroy'})
  if 'sell' in selector:
    data.append({'x': retrieve.sretrieve(tab, slider)['x'],
                 'y': retrieve.sretrieve(tab, slider)['y'], 'type': 'line', 'name': 'Sells', 'fill': 'tozeroy'})

  figure = {
      'data': data,
      'layout': {
          'title': title,
          "titlefont": dict(
              family='Andale Mono, monospace',
              size=33,
              color='#0E0D85'
          ),
          'legend': dict(
              x=0.95,
              y=1.22
          ),

          'xaxis': dict(
              title='Price ($)',
              showticklabels=True,
              showline=True,
              linewidth=2,
              nticks=18,
              tickangle=55,
              tickfont=dict(
                  family='Andale Mono, monospace',
                  size=12),
              titlefont=dict(
                  family='Andale Mono, monospace',
                  color='#0E0D85',
                  size=21
              )),
          'yaxis': dict(
              title='Volume',
              showticklabels=True,
              showline=True,
              linewidth=2,
              tickfont=dict(
                  family='Andale Mono, monospace',
                  size=12),
              titlefont=dict(
                  family='Andale Mono, monospace',
                  color='#0E0D85',
                  size=21

              )),
          'hovermode': 'closest',

      }
  }
  return figure


def tgraph(selector, tab, slider):
  data = []
  title = tab
  # print(slider)
  data.clear()
  if 'trades' in selector:
    data.append(
        go.Scatter(
            x=retrieve.tretrieve(tab, slider)['x'],
            y=retrieve.tretrieve(tab, slider)['y'],
            text=retrieve.tretrieve(tab, slider)['text'],
            name='Trades',
            mode='markers',
            opacity=0.6,
            marker={
                'size': 11,
                'color': '#c43838',

            }
        ),
    )

  figure = {
      'data': data,
      'layout': {
          'title': title,
          "titlefont": dict(
              family='Andale Mono, monospace',
              size=33,
              weight='bold',
              color='#0E0D85'),


          'xaxis': dict(
              title='Time',
              showticklabels=True,
              showline=True,
              linewidth=2,
              nticks=10,
              tickangle=43,
              tickfont=dict(
                  family='Andale Mono, monospace',
                  size=11),
              titlefont=dict(
                  family='Andale Mono, monospace',
                  color='#0E0D85',
                  size=21,


              )),
          'yaxis': dict(
              title='Price ($)',
              showticklabels=True,
              showline=True,
              linewidth=2,
              tickfont=dict(
                  family='Andale Mono, monospace',
                  size=12),
              titlefont=dict(
                  family='Andale Mono, monospace',
                  color='#0E0D85',
                  size=21,


              )),
          'hovermode': 'closest',

      }
  }
  return figure
