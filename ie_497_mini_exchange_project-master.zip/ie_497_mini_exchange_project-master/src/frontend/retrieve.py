import datetime
from os import path
from statistics import mean

import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import plotly.graph_objs as go
from dash.dependencies import Input, Output

buys_file_path = path.join(path.dirname(__file__), 'resources', 'buy.csv')
sells_file_path = path.join(path.dirname(__file__), 'resources', 'sell.csv')
trades_file_path = path.join(path.dirname(__file__), 'resources', 'trade.csv')


def getDatetime(currentData, slider):
  dateSet = []
  for x in currentData:
    try:
      dateSet.append(datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S'))
    except:
      continue
  return dateSet


def getPrice(market):
  trades = pd.read_csv(trades_file_path)
  dateSet = [()]
  for x in trades[trades['Market'] == market].to_dict('rows'):
    try:
      dateSet.append((datetime.datetime.strptime(
          x['Time'], '%Y-%m-%d %H:%M:%S'), x['Price']))
    except:
      continue
  dateSet = sorted(dateSet)
  return dateSet[len(dateSet)-1][1]


def retrieve(market, slider):
  buys = pd.read_csv(buys_file_path)
  value = {
      'x': '',
      'y': '',
      'text': ''
  }
  range = int(slider[0] * len(buys)/10)
  print('buy-graph')

  value['y'] = buys[buys['Market'] == market]['Volume'][-range:]
  value['x'] = buys[buys['Market'] == market]['Price'][-range:]
  value['text'] = buys[buys['Market'] == market]['ID'][-range:]
  return value


def sretrieve(market, slider):
  sells = pd.read_csv(sells_file_path)
  value = {
      'x': '',
      'y': '',
      'text': ''
  }
  range = int(slider[0] * len(sells)/10)
  value['y'] = sells[sells['Market'] == market]['Volume'][:range]
  value['x'] = sells[sells['Market'] == market]['Price'][:range]
  value['text'] = sells[sells['Market'] == market]['ID']
  print('sell-graph')
  return value


def tretrieve(market, slider):
  trades = pd.read_csv(trades_file_path)
  value = {
      'x': '',
      'y': '',
      'text': ''

  }
  print(trades[trades['Market'] == market]['Price'])

  value['x'] = getDatetime(trades[trades['Market'] == market]['Time'], slider)
  print('trade-graph')
  value['y'] = trades[trades['Market'] == market]['Price']
  value['text'] = trades[trades['Market'] == market]['ID']
  return value


def table(selector, tab):
  buys = pd.read_csv(buys_file_path)
  x = buys[buys['Market'] == tab].to_dict('rows')
  print('buy-table')
  return sorted(x, key=lambda elem: elem['Price'])


def stable(selector, tab):
  sells = pd.read_csv(sells_file_path)
  x = sells[sells['Market'] == tab].to_dict('rows')
  print('sell-table')
  return sorted(x, key=lambda elem: elem['Price'])


def ttable(selector, tab):
  trades = pd.read_csv(trades_file_path)
  x = trades[trades['Market'] == tab].to_dict('rows')
  print('trade-table')
  return sorted(x, key=lambda elem: elem['Price'])


def hovertable(selector, tab, hover):
  trades = pd.read_csv(trades_file_path)
  print('hover-table')
  if hover is None:
    x = trades[trades['Market'] == tab].to_dict('rows')
    return sorted(x, key=lambda elem: elem['Volume'])[:1]
  else:
    try:
      x = trades[trades['ID'] == (hover['points'][0]['text'])]
      z = x[x['Market'] == tab].to_dict('rows')
      return z
    except:
      exit


def bar(hover, market):
  trades = pd.read_csv(trades_file_path)
  print('bar')
  if hover != None:
    hoverPrice = hover['points'][0]['text']
    one = trades[trades['ID'] == hoverPrice]['Volume']
    x = trades[trades['Market'] == market]['Volume']
    dif = x.max() - x.min()
    return (one/dif) * 10
