import logging
import os
import socket
from collections import deque
from errno import EAGAIN, EWOULDBLOCK

from src.common.constants import *
from src.common.nonblocking_tcp_server import TCPServer

from .constants import *
from .fix_session import FixSession

# TODO: After completing single-threaded version, try implementing hybrid version with epoll and worker thread pool
# TODO: Use TCP_NODELAY for all sockets? + check return values of socket calls for error handling
# TODO: When a socket is disconnected, need to inform fix_session + what if messages pending + what if in `events` list (add `if` in dict check?)?
# TODO: Log received data and outgoing data in server?


class GatewayConnection:
  def __init__(self, fix_session: FixSession, client_socket: socket.socket, ome_socket: socket.socket):
    self.fix_session = fix_session
    self.client_socket = client_socket
    self.ome_socket = ome_socket


class GatewayServer(TCPServer):
  def __init__(self, server_address: tuple, backlog: int = MAX_SERVER_BACKLOG):
    super().__init__(server_address, backlog)
    # Create outgoing message queues + dictionary for connections
    self._message_queues = dict()
    self._fd_to_connection = dict()

  def _handle_new_connection(self) -> None:
    client_socket, client_address = self._server_socket.accept()
    logging.info('Received new connection from {}'.format(client_address))

    # Establish new TCP connection to OME for this client
    ome_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ome_socket.connect((os.getenv('MATCHING_ENGINE_HOST'),
                        int(os.getenv('MATCHING_ENGINE_PORT'))))
    client_socket.setblocking(False)
    ome_socket.setblocking(False)

    # Create queues that FIX session can use to send outgoing messages
    client_msg_queue = deque()
    ome_msg_queue = deque()
    self._message_queues[client_socket.fileno()] = client_msg_queue
    self._message_queues[ome_socket.fileno()] = ome_msg_queue

    # Create new FIX session and encapsulate associated data in a GatewayConnection object
    fix_session = FixSession(client_msg_queue, ome_msg_queue)
    connection = GatewayConnection(
        fix_session, client_socket, ome_socket)
    self._fd_to_connection[client_socket.fileno()] = connection
    self._fd_to_connection[ome_socket.fileno()] = connection

    # Start polling for read events on new sockets
    self._poller.register(client_socket.fileno(), READ_ONLY)
    # TODO: Technically unnecessary
    self._poller.register(ome_socket.fileno(), READ_ONLY)

  def _handle_pollin_event(self, fd: int) -> None:
    # Retrieve connection object for ready file-descriptor
    connection: GatewayConnection = self._fd_to_connection[fd]
    fix_session = connection.fix_session
    is_client_socket = connection.client_socket.fileno() == fd
    ready_socket = connection.client_socket if is_client_socket else connection.ome_socket

    data = self._read_data_from_socket(ready_socket)
    if (len(data) > 0):
      if (is_client_socket):
        fix_session.process_data_from_client(data)
      else:
        fix_session.process_data_from_ome(data)

      # Listen for write events on appropriate socket(s)
      client_outgoing_msg_queue: deque = self._message_queues[connection.client_socket.fileno(
      )]
      ome_outgoing_msg_queue: deque = self._message_queues[connection.ome_socket.fileno(
      )]
      if (len(client_outgoing_msg_queue) > 0):
        self._poller.modify(connection.client_socket.fileno(), READ_WRITE)
      if (len(ome_outgoing_msg_queue) > 0):
        self._poller.modify(connection.ome_socket.fileno(), READ_WRITE)

  def _handle_pollout_event(self, fd: int) -> None:
    connection: GatewayConnection = self._fd_to_connection[fd]
    is_client_socket = connection.client_socket.fileno() == fd
    ready_socket = connection.client_socket if is_client_socket else connection.ome_socket
    socket_msg_queue: deque = self._message_queues[ready_socket.fileno()]

    did_error_occur = False
    total_bytes_sent = 0
    can_send_more_data = True
    while (len(socket_msg_queue) > 0 and can_send_more_data):
      msg_to_send = socket_msg_queue[0]
      if (msg_to_send == TERMINATE_CONNECTION_MSG):
        logging.info(
            "Terminating Gateway connection with {}".format(ready_socket.getpeername()))
        self._terminate_gateway_connection(connection)
        total_bytes_sent += len(msg_to_send)
        can_send_more_data = False
      else:
        try:
          bytes_written = ready_socket.send(msg_to_send)
          if (bytes_written <= 0):
            can_send_more_data = False
          elif (bytes_written == len(msg_to_send)):
            total_bytes_sent += bytes_written
            socket_msg_queue.popleft()
          else:
            total_bytes_sent += bytes_written
            socket_msg_queue[0] = socket_msg_queue[0][bytes_written:]
            can_send_more_data = False
        except socket.error as err:
          if (err.errno != EWOULDBLOCK and err.errno != EAGAIN):
            logging.exception('Exception occurred while writing data to socket: {}'.format(
                ready_socket.getpeername()))
            did_error_occur = True
          can_send_more_data = False

    if (did_error_occur or total_bytes_sent == 0):
      self._shutdown_socket(ready_socket)
    elif (len(socket_msg_queue) == 0):
      # If no more data to send, stop listening for write events on socket
      self._poller.modify(ready_socket.fileno(), READ_ONLY)

  def _handle_socket_disconnect(self, fd: int, result_of_error: bool) -> None:
    connection: GatewayConnection = self._fd_to_connection[fd]
    is_client_socket = connection.client_socket.fileno() == fd
    disconnected_socket = connection.client_socket if is_client_socket else connection.ome_socket

    if (result_of_error):
      logging.error('An error occurred on connection with {}'.format(
          disconnected_socket.getpeername()))
    else:
      logging.info(
          '{} hung up. Performing cleanup'.format(disconnected_socket.getpeername()))
    self._shutdown_socket(disconnected_socket)

  def _terminate_gateway_connection(self, connection: GatewayConnection) -> None:
    self._shutdown_socket(connection.client_socket)
    self._shutdown_socket(connection.ome_socket)

  # TODO: Need to ensure fix_session is aware of shutdown so doesn't try to write any more data
  def _shutdown_socket(self, sock: socket.socket) -> None:
    del self._fd_to_connection[sock.fileno()]
    del self._message_queues[sock.fileno()]
    super()._shutdown_socket(sock)

  def shutdown(self) -> None:
    for connection in self._fd_to_connection.values():
      super()._shutdown_socket(connection.client_socket)
      super()._shutdown_socket(connection.ome_socket)
    super().shutdown()
