from simplefix.constants import *

# TODO: Can perform stronger validation by giving each tag a type + is_required and ensuring value is not null for that type
FIX_MSG_TYPE_REQUIRED_TAGS = {
    MSGTYPE_LOGON: [TAG_ENCRYPTMETHOD, TAG_HEARTBTINT],
    # TestReqID is required when heartbeat is the result of a Test Request message
    MSGTYPE_HEARTBEAT: [],
    MSGTYPE_NEW_ORDER_SINGLE: [
        TAG_CLORDID,
        TAG_HANDLINST,
        TAG_SYMBOL,
        TAG_SIDE,
        TAG_TRANSACTTIME,
        TAG_ORDERQTY,
        TAG_ORDTYPE,
        TAG_PRICE
    ],
    MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST: [
        TAG_ORIGCLORDID,
        TAG_CLORDID,
        TAG_HANDLINST,
        TAG_SYMBOL,
        TAG_SIDE,
        TAG_TRANSACTTIME,
        TAG_ORDERQTY,
        TAG_ORDTYPE,
        TAG_PRICE
    ],
    # Full cancellations only; any OrderQty provided is ignored. To reduce quantity of an order use the Order Cancel / Replace Request.
    MSGTYPE_ORDER_CANCEL_REQUEST: [
        TAG_ORIGCLORDID,
        TAG_CLORDID,
        TAG_SYMBOL,
        TAG_SIDE,
        TAG_TRANSACTTIME
    ]
}
# Currently only limit orders are supported
SUPPORTED_ORDER_TYPES = [ORDTYPE_LIMIT]

TERMINATE_CONNECTION_MSG = 'TERMINATE_CONNECTION'
