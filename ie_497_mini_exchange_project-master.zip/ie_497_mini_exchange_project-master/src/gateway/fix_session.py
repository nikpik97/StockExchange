import logging
from collections import deque

from simplefix import *

from src.common.constants import *
from src.common.fix_message_buffer import FixMessageBuffer
from src.common.utils import create_msg_with_header, parse_fix_messages

from .constants import *
from .utils import *

# TODO: Gracefully handle disconnect
# TODO: Docstring comments
# TODO: Need a way to send perioidic heartbeat messages + handle logout messages


class FixSession:
  def __init__(self, client_outgoing_msg_queue: deque, ome_outgoing_msg_queue: deque):
    self._client_comp_id = b''
    self._incoming_msg_seq_num = 1
    self._outgoing_msg_seq_num = 1
    self._heartbeat_interval = 0
    self._is_client_authenticated = False
    self._client_incoming_msg_buffer = FixMessageBuffer()
    self._ome_incoming_msg_buffer = FixMessageBuffer()
    self._client_outgoing_msg_queue = client_outgoing_msg_queue
    self._ome_outgoing_msg_queue = ome_outgoing_msg_queue

  def process_data_from_client(self, data: bytes) -> None:
    fix_messages = parse_fix_messages(data, self._client_incoming_msg_buffer)
    for msg in fix_messages:
      self._validate_and_process_fix_msg(msg)

  def process_data_from_ome(self, data: bytes) -> None:
    # logging.info('Received {} from OME'.format(data))
    fix_messages = parse_fix_messages(data, self._ome_incoming_msg_buffer)
    for msg in fix_messages:
      self._send_message_to_client(msg)

  def _validate_and_process_fix_msg(self, msg: FixMessage) -> None:
    if (not self._is_client_authenticated):
      self._attempt_client_authentication(msg)
      return

    if (msg is None):
      logging.warning(
          "Non-FIX message received from client {}".format(self._client_comp_id))
      return

    # According to FIX protocol, if msg passes de-encryption, CheckSum and BodyLength checks,
    # the incoming sequence number should be incremented
    self._incoming_msg_seq_num += 1
    session_reject_reason, ref_tag_id = validate_fix_message(
        msg, self._client_comp_id, self._incoming_msg_seq_num)
    if (session_reject_reason is None):
      self._handle_new_client_message(msg)
    else:
      self._handle_invalid_message(msg, session_reject_reason, ref_tag_id)

  def _handle_new_client_message(self, msg: FixMessage) -> None:
    """Forwards FIX message to appropriate function for handling"""
    msg_type = msg.get(TAG_MSGTYPE)

    if (
        msg_type == MSGTYPE_NEW_ORDER_SINGLE or
        msg_type == MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST or
        msg_type == MSGTYPE_ORDER_CANCEL_REQUEST
    ):
      self._handle_order_related_message(msg)
    elif (msg_type == MSGTYPE_HEARTBEAT):
      pass
    elif (msg_type == MSGTYPE_TEST_REQUEST):
      pass
    else:
      logging.warn('Unknown FIX message received from client {}: {}'.format(
          self._client_comp_id, msg))

  def _handle_order_related_message(self, msg: FixMessage) -> None:
    """
    Validates an order-related message. If message passes validation, sends it to
    Matching Engine for further processing. Otherwise, Reject msg is sent to client
    """
    session_reject_reason, ref_tag_id = validate_fix_order_message(msg)

    if (session_reject_reason is None):
      logging.info("Received order related message from client {}: {}".format(
          self._client_comp_id, msg))
      # TODO: Log that msg is being sent to OME here (maybe create wrapper function)
      self._ome_outgoing_msg_queue.append(msg.encode())
    else:
      self._handle_invalid_message(msg, session_reject_reason, ref_tag_id)

  def _handle_invalid_message(self, msg: FixMessage, session_reject_reason: bytes, ref_tag_id: bytes) -> None:
    if (ref_tag_id == TAG_MSGSEQNUM and session_reject_reason == SESSIONREJECTREASON_OTHER):
      logging.warning('Message gap detected for client {} [Excepted Seq. #: {} vs. Actual Seq. #: {}'.format(
          self._client_comp_id, self._incoming_msg_seq_num, msg.get(TAG_MSGSEQNUM)))
      # TODO: Handle correctly by sending a "ReSend" request message
      return

    logging.warning("Rejecting invalid FIX message {} from client {} due to {} ({})".format(
        msg, self._client_comp_id, session_reject_reason, ref_tag_id))
    reject_msg = create_msg_with_header(MSGTYPE_REJECT, self._client_comp_id)
    reject_msg.append_pair(TAG_REFSEQNUM, msg.get(TAG_MSGSEQNUM))
    reject_msg.append_pair(TAG_REF_TAG_ID, ref_tag_id)
    reject_msg.append_pair(TAG_REF_MSG_TYPE, msg.get(TAG_MSGTYPE))
    reject_msg.append_pair(TAG_SESSIONREJECTREASON, session_reject_reason)
    self._send_message_to_client(reject_msg)

  def _attempt_client_authentication(self, msg: FixMessage) -> None:
    if (msg is None or msg.get(TAG_MSGTYPE) != MSGTYPE_LOGON or validate_fix_message(msg, self._client_comp_id, self._incoming_msg_seq_num)[0] is not None):
      logging.warning(
          'Valid Logon message was not received from new connection')
      logout_msg = create_msg_with_header(MSGTYPE_LOGOUT, 'UNKNOWN')
      logout_msg.append_pair(
          TAG_TEXT, 'Valid Logon message is required to establish FIX session')
      self._send_message_to_client(logout_msg)

      # Normally, we would wait for a "Logout" reply, but since session was never established, we can simply close the connection
      # TODO: Instead of adding raw bytes to queue, create wrapper object that contains msg_type enum (FIX_MSG or ACTION)
      self._client_outgoing_msg_queue.append(TERMINATE_CONNECTION_MSG)
      return

    logging.info('Received new Logon message: {}'.format(msg))
    # TODO: what if heartbeat interval is not an int? + authenticate + verify target_comp_id
    self._heartbeat_interval = int(msg.get(TAG_HEARTBTINT))
    self._client_comp_id = msg.get(TAG_SENDER_COMPID)
    self._is_client_authenticated = True

    logging.info("FIX session successfully established with client {} (heartbeat interval {})".format(
        self._client_comp_id, self._heartbeat_interval))

    # Reply to client with Logon message
    logon_reply_msg = create_msg_with_header(
        MSGTYPE_LOGON, self._client_comp_id)
    logon_reply_msg.append_pair(TAG_ENCRYPTMETHOD, ENCRYPTMETHOD_NONE)
    logon_reply_msg.append_pair(TAG_HEARTBTINT, msg.get(TAG_HEARTBTINT))
    self._send_message_to_client(logon_reply_msg)

  # TODO: Save outgoing messages in memory to allow re-transmission on Resend Request
  def _send_message_to_client(self, msg: FixMessage) -> None:
    """
    Adds sequence number + timestamp to FIX message, encodes it, adds it to
    the outgoing msg queue and increments the outgoing msg sequence number.
    """
    msg.append_pair(TAG_MSGSEQNUM, self._outgoing_msg_seq_num, header=True)
    msg.append_utc_timestamp(TAG_SENDING_TIME, precision=6, header=True)
    encoded_msg = msg.encode()
    # TODO: Indicate which message type (human-readable value) is being sent
    logging.info("Sending FIX message {} to client {}".format(
        msg, self._client_comp_id))
    self._client_outgoing_msg_queue.append(encoded_msg)
    self._outgoing_msg_seq_num += 1
