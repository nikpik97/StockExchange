from datetime import datetime

from simplefix.constants import *
from simplefix.message import FixMessage

from src.common.constants import (EXCHANGE_COMP_ID, FIX_BEGIN_STRING,
                                  TIMESTAMP_FORMAT)
from src.common.utils import is_float, is_int, is_valid_timestamp

from .constants import FIX_MSG_TYPE_REQUIRED_TAGS, SUPPORTED_ORDER_TYPES


def validate_fix_message(msg: FixMessage, client_comp_id: bytes, expected_seq_num: int) -> tuple:
  """
  Performs basic session-level validation on FIX messages.
  Returns a tuple representing session reject reason and the associated tag with the issue.
  """
  msg_type = msg.get(TAG_MSGTYPE)
  if (msg_type not in FIX_MSG_TYPE_REQUIRED_TAGS):
    return (SESSIONREJECTREASON_INVALID_MSGTYPE, TAG_MSGTYPE)

  # Validate standard header
  sender_comp_id = msg.get(TAG_SENDER_COMPID)
  msg_seq_num = msg.get(TAG_MSGSEQNUM)
  if (msg.get(TAG_BEGINSTRING) != FIX_BEGIN_STRING):
    return (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_BEGINSTRING)
  elif (msg.get(TAG_TARGET_COMPID) != EXCHANGE_COMP_ID):
    return (SESSIONREJECTREASON_COMPID_PROBLEM, TAG_TARGET_COMPID)
  elif ((msg_type != MSGTYPE_LOGON and sender_comp_id != client_comp_id)
        or (msg_type == MSGTYPE_LOGON and (sender_comp_id is None or sender_comp_id == b''))):
    return (SESSIONREJECTREASON_COMPID_PROBLEM, TAG_SENDER_COMPID)
  elif (not is_valid_timestamp(msg.get(TAG_SENDING_TIME))):
    return (SESSIONREJECTREASON_SENDINGTIME_ACCURACY_PROBLEM, TAG_SENDING_TIME)
  elif (not is_int(msg_seq_num) or int(msg_seq_num) != expected_seq_num):
    return (SESSIONREJECTREASON_OTHER, TAG_MSGSEQNUM)

  # Validate message body
  required_tags = FIX_MSG_TYPE_REQUIRED_TAGS[msg.get(TAG_MSGTYPE)]
  for tag in required_tags:
    if (msg.get(tag) is None):
      return (SESSIONREJECTREASON_REQUIRED_TAG_MISSING, tag)

  return (None, None)


def validate_fix_order_message(msg: FixMessage) -> tuple:
  """Performs validation for order related messages. See `validate_fix_message` for return type"""
  msg_type = msg.get(TAG_MSGTYPE)
  symbol = msg.get(TAG_SYMBOL)
  side = msg.get(TAG_SIDE)
  transact_time = msg.get(TAG_TRANSACTTIME)

  if (symbol is None or symbol == b''):
    return (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_SYMBOL)
  elif (side != SIDE_BUY and side != SIDE_SELL):
    return (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_SIDE)
  elif (not is_valid_timestamp(transact_time)):
    return (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_TRANSACTTIME)

  if (msg_type == MSGTYPE_NEW_ORDER_SINGLE or msg_type == MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST):
    quantity = msg.get(TAG_ORDERQTY)
    order_type = msg.get(TAG_ORDTYPE)
    price = msg.get(TAG_PRICE)

    if (not is_float(quantity) or float(quantity) <= 0):
      return (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_ORDERQTY)
    elif (order_type not in SUPPORTED_ORDER_TYPES):
      return (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_ORDTYPE)
    elif (not is_float(price) or float(price) < 0):
      return (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_PRICE)

  return (None, None)
