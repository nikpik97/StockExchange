import logging

from .constants import HOST, PORT
from .server import GatewayServer

# TODO: Need to determine proper amount and location of logging

if __name__ == "__main__":
  # TODO: Read environment variables
  logging.basicConfig(format='%(asctime)s [%(levelname)s]: %(message)s',
                      level=logging.INFO, datefmt='%m/%d/%Y %I:%M:%S %p')

  server = GatewayServer((HOST, PORT))
  try:
    logging.info('FIX gateway listening on {}:{}'.format(HOST, PORT))
    server.serve_forever()
  except KeyboardInterrupt:
    pass
  finally:
    server.shutdown()
