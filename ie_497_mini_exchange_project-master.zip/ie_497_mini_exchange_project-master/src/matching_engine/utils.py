from datetime import datetime

from simplefix.constants import *
from simplefix.message import FixMessage

from src.common.constants import *
from src.common.utils import create_msg_with_header

from .model.order import Order, OrderSide, OrderStatus, OrderTrade


def is_price_acceptable(order: Order, other_side_price: float) -> bool:
  if (order.side == OrderSide.BUY):
    return (other_side_price <= order.price)
  else:
    return (other_side_price >= order.price)


def calculate_average_trade_price(order: Order) -> float:
  if (len(order.trades) == 0):
    return 0.0

  total_quantity = 0.0
  total_trades_value = 0.0
  for trade in order.trades:
    total_trades_value += (trade.quantity * trade.price)
    total_quantity += trade.quantity
  return (total_trades_value / total_quantity)


# TODO: Technically, this function only needs to accept list of trades as a parameter
def bundle_most_recent_trades(matched_orders: list) -> OrderTrade:
  total_trade_value = 0.0
  total_quantity = 0.0

  for order in matched_orders:
    most_recent_trade: OrderTrade = order.trades[len(order.trades) - 1]
    total_trade_value += (most_recent_trade.quantity * most_recent_trade.price)
    total_quantity += most_recent_trade.quantity

  average_trade_price = (total_trade_value / total_quantity)
  return OrderTrade(price=average_trade_price, quantity=total_quantity)


def map_fix_message_to_order(msg: FixMessage, order_id: str) -> Order:
  client_order_id = msg.get(TAG_CLORDID).decode()
  client_id = msg.get(TAG_SENDER_COMPID).decode()
  symbol = msg.get(TAG_SYMBOL).decode().strip().upper()
  side = OrderSide.BUY if (msg.get(TAG_SIDE) == SIDE_BUY) else OrderSide.SELL
  quantity = float(msg.get(TAG_ORDERQTY))
  order_type = msg.get(TAG_ORDTYPE)
  price = float(msg.get(TAG_PRICE))
  created_on = datetime.strptime(
      msg.get(TAG_TRANSACTTIME).decode(), TIMESTAMP_FORMAT)

  return Order(order_id, client_order_id, client_id, symbol, side, quantity, order_type, price, created_on)


def generate_execution_report_message(order: Order, fill: bool, **kwargs: dict) -> FixMessage:
  execution_report = create_msg_with_header(
      MSGTYPE_EXECUTION_REPORT, bytes(order.client_id, encoding='utf8'))

  execution_report.append_pair(TAG_ORDERID, order.order_id)
  execution_report.append_pair(TAG_CLORDID, order.client_order_id)
  if (order.orig_client_order_id is not None):
    execution_report.append_pair(TAG_ORIGCLORDID, order.orig_client_order_id)
  execution_report.append_pair(TAG_EXECTRANSTYPE, EXECTRANSTYPE_NEW)
  execution_report.append_pair(
      TAG_EXECTYPE, kwargs.get('exec_type', order.order_status))
  execution_report.append_pair(TAG_ORDSTATUS, order.order_status)
  execution_report.append_pair(TAG_SYMBOL, order.symbol)
  execution_report.append_pair(
      TAG_SIDE, SIDE_BUY if order.side == OrderSide.BUY else SIDE_SELL)
  execution_report.append_pair(TAG_ORDERQTY, order.quantity)
  execution_report.append_pair(TAG_PRICE, order.price)
  execution_report.append_pair(
      TAG_AVGPX, calculate_average_trade_price(order))
  execution_report.append_pair(
      TAG_CUMQTY, order.quantity - order.remaining_quantity)
  execution_report.append_utc_timestamp(TAG_TRANSACTTIME, precision=6)

  if (fill):
    most_recent_trade: OrderTrade = order.trades[len(order.trades) - 1]
    execution_report.append_pair(TAG_LASTQTY, most_recent_trade.quantity)
    execution_report.append_pair(TAG_LASTPX, most_recent_trade.price)
  else:
    execution_report.append_pair(TAG_LASTQTY, 0)
    execution_report.append_pair(TAG_LASTPX, 0)

  if (order.order_status != OrderStatus.CANCELED and order.order_status != OrderStatus.REJECTED):
    execution_report.append_pair(TAG_LEAVES_QTY, order.remaining_quantity)
  else:
    execution_report.append_pair(TAG_LEAVES_QTY, 0)

  if ('reject_reason' in kwargs):
    execution_report.append_pair(
        TAG_ORDERREJREASON, kwargs['reject_reason'])

  return execution_report


def generate_order_cancel_reject_message(
    client_comp_id, order_id, cl_order_id, orig_cl_order_id, ord_status, rej_response_to, rej_reason
) -> FixMessage:
  order_cancel_reject_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REJECT, client_comp_id)
  order_cancel_reject_msg.append_pair(TAG_ORDERID, order_id)
  order_cancel_reject_msg.append_pair(TAG_CLORDID, cl_order_id)
  order_cancel_reject_msg.append_pair(TAG_ORIGCLORDID, orig_cl_order_id)
  order_cancel_reject_msg.append_pair(TAG_ORDSTATUS, ord_status)
  order_cancel_reject_msg.append_pair(TAG_CXLREJRESPONSETO, rej_response_to)
  order_cancel_reject_msg.append_pair(TAG_CXLREJREASON, rej_reason)
  return order_cancel_reject_msg
