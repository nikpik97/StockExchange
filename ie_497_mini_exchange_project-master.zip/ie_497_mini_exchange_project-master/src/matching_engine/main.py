import logging

from .server import MatchingEngineServer

if __name__ == "__main__":
  # TODO: Read environment variables
  logging.basicConfig(format='%(asctime)s [%(levelname)s]: %(message)s',
                      level=logging.INFO, datefmt='%m/%d/%Y %I:%M:%S %p')
  HOST = '127.0.0.1'
  PORT = 8081

  server = MatchingEngineServer((HOST, PORT))
  try:
    logging.info(
        'Order Matching Engine (OME) Server listening on {}:{}'.format(HOST, PORT))
    server.serve_forever()
  except KeyboardInterrupt:
    pass
  finally:
    server.shutdown()
