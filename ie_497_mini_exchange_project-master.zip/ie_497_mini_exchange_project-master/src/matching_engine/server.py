import logging
import select
import socket
from collections import deque

from simplefix.constants import *
from simplefix.message import FixMessage
from simplefix.parser import FixParser

from src.common.constants import *
from src.common.fix_message_buffer import FixMessageBuffer
from src.common.nonblocking_tcp_server import TCPServer
from src.common.utils import parse_fix_messages

from .central_order_book import CentralOrderBook

# TODO: Establish connection with ticker plant as well (just need to listen for write events, not read)
# TODO: Should we combine read data + parsing steps into one?


class Connection:
  def __init__(self, connection_socket: socket.socket):
    self.connection_socket = connection_socket
    self.buffer = FixMessageBuffer()


class MatchingEngineServer(TCPServer):
  def __init__(self, server_address: tuple, backlog: int = MAX_SERVER_BACKLOG):
    super().__init__(server_address, backlog)
    self._central_order_book = CentralOrderBook(
        self._add_outgoing_msg_to_gateway_queue, self._add_outgoing_msg_to_ticker_plant_queue)
    self._client_id_to_fd = dict()
    self._message_queues = dict()
    self._fd_to_connection = dict()

  def _handle_new_connection(self) -> None:
    connection_socket, connection_address = self._server_socket.accept()
    logging.info(
        'OME Server received new connection from {}'.format(connection_address))

    connection_socket.setblocking(False)
    connection = Connection(connection_socket)
    self._message_queues[connection_socket.fileno()] = deque()
    self._fd_to_connection[connection_socket.fileno()] = connection
    # Start polling for read events on new socket
    self._poller.register(connection_socket.fileno(), READ_ONLY)

  def _handle_pollin_event(self, fd: int) -> None:
    connection: Connection = self._fd_to_connection[fd]
    data = self._read_data_from_socket(connection.connection_socket)
    fix_messages = parse_fix_messages(data, connection.buffer)

    for msg in fix_messages:
      # TODO: Ensure type mismatch does not happen
      if (msg.get(TAG_SENDER_COMPID) not in self._client_id_to_fd):
        self._client_id_to_fd[msg.get(TAG_SENDER_COMPID)] = fd
      self._central_order_book.process_msg_from_gateway(msg)

  # TODO: Try to reduce duplicated code between this and gateway server
  def _handle_pollout_event(self, fd: int) -> None:
    connection: Connection = self._fd_to_connection[fd]
    ready_socket = connection.connection_socket
    socket_msg_queue: deque = self._message_queues[ready_socket.fileno()]

    did_error_occur = False
    total_bytes_sent = 0
    can_send_more_data = True
    while (len(socket_msg_queue) > 0 and can_send_more_data):
      msg_to_send = socket_msg_queue[0]
      try:
        bytes_written = ready_socket.send(msg_to_send)
        if (bytes_written <= 0):
          can_send_more_data = False
        elif (bytes_written == len(msg_to_send)):
          total_bytes_sent += bytes_written
          socket_msg_queue.popleft()
        else:
          total_bytes_sent += bytes_written
          socket_msg_queue[0] = socket_msg_queue[0][bytes_written:]
          can_send_more_data = False
      except socket.error as err:
        if (err.errno != EWOULDBLOCK and err.errno != EAGAIN):
          logging.exception('Exception occurred while writing data to socket: {}'.format(
              ready_socket.getpeername()))
          did_error_occur = True
        can_send_more_data = False

    if (did_error_occur or total_bytes_sent == 0):
      self._shutdown_socket(ready_socket)
    elif (len(socket_msg_queue) == 0):
      self._poller.modify(ready_socket.fileno(), READ_ONLY)

  # TODO: Use a different named function to reduce duplicated code at end
  def _handle_socket_disconnect(self, fd: int, result_of_error: bool) -> None:
    connection: Connection = self._fd_to_connection[fd]
    disconnected_socket = connection.connection_socket

    if (result_of_error):
      logging.error('An error occurred on connection with {}'.format(
          disconnected_socket.getpeername()))
    else:
      logging.info(
          '{} hung up. Performing cleanup'.format(disconnected_socket.getpeername()))
    self._shutdown_socket(disconnected_socket)

  def _add_outgoing_msg_to_gateway_queue(self, encoded_msg: bytes, client_id: bytes) -> None:
    if (client_id not in self._client_id_to_fd):
      return

    client_id_fd: int = self._client_id_to_fd[client_id]
    fd_outgoing_msg_queue: deque = self._message_queues[client_id_fd]
    fd_outgoing_msg_queue.append(encoded_msg)
    # Listen for write events on socket
    self._poller.modify(client_id_fd, READ_WRITE)

  def _add_outgoing_msg_to_ticker_plant_queue(self):
    # TODO: Implement
    pass

  # TODO: Release any more resources that are associated with this socket
  def _shutdown_socket(self, sock: socket.socket) -> None:
    # TODO: Remove any entries that have `sock.fileno()` as value in `self.__client_id_to_fd`?
    del self._fd_to_connection[sock.fileno()]
    del self._message_queues[sock.fileno()]
    super()._shutdown_socket(sock)

  def shutdown(self):
    for connection in self._fd_to_connection.values():
      self._poller.unregister(connection.connection_socket.fileno())
      connection.connection_socket.shutdown(socket.SHUT_RDWR)
      connection.connection_socket.close()
    super().shutdown()
