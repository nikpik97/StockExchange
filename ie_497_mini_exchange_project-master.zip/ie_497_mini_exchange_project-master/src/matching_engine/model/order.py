from enum import Enum
from datetime import datetime
from collections import namedtuple

# TODO: Get rid of Enums entirely and just use SimpleFix constants instead


class OrderType(Enum):
  # Currently, only limit orders are supported by the exchange
  LIMIT = 1


class OrderSide(Enum):
  BUY = b'1'
  SELL = b'2'


class OrderStatus():
  NEW = b'0'
  PARTIALLY_FILLED = b'1'
  FILLED = b'2'
  DONE_FOR_DAY = b'3'
  CANCELED = b'4'
  REPLACED = b'5'
  PENDING_CANCEL = b'6'
  REJECTED = b'8'
  PENDING_REPLACE = b'E'


OrderTrade = namedtuple('OrderTrade', ['price', 'quantity'])


class Order:
  def __init__(
      self,
      order_id: str,
      client_order_id: str,
      client_id: str,
      symbol: str,
      side: OrderSide,
      quantity: float,
      order_type: OrderType,
      price: float,
      created_on: datetime
  ):
    self.order_id = order_id
    self.client_order_id = client_order_id
    self.client_id = client_id
    self.symbol = symbol
    self.side = side
    self.quantity = quantity
    self.order_type = order_type
    self.price = price
    self.created_on = created_on

    self.orig_client_order_id = None
    self.remaining_quantity = quantity
    self.order_status = OrderStatus.NEW
    self.trades = []

  def __eq__(self, value):
    return self.order_id == value.order_id

  def __str__(self):
    return '{} {} {} {} {}'.format(self.order_id, self.symbol, self.side, self.remaining_quantity, self.price)
