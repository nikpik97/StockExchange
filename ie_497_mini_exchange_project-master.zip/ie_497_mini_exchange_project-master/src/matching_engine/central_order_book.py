import logging
from typing import Any, Callable

from simplefix.constants import *
from simplefix.message import FixMessage

from src.common.constants import (REJ_RESPONSE_TO_ORD_CANCEL_REPLACE_REQUEST,
                                  REJ_RESPONSE_TO_ORD_CANCEL_REQUEST)

from .instrument_order_book import InstrumentOrderBook
from .model.order import Order, OrderSide
from .utils import (generate_order_cancel_reject_message,
                    map_fix_message_to_order)


class CentralOrderBook:
  def __init__(self, send_msg_to_gateway: Callable[[bytes, bytes], None], send_msg_to_ticker_plant: Callable[[Any], None]):
    self._send_msg_to_gateway = send_msg_to_gateway
    self._send_msg_to_ticker_plant = send_msg_to_ticker_plant
    self._curr_exec_id = 0
    self._curr_order_id = 0
    self._instrument_order_books = dict()

  def process_msg_from_gateway(self, msg: FixMessage) -> None:
    msg_type = msg.get(TAG_MSGTYPE)
    if (msg_type == MSGTYPE_NEW_ORDER_SINGLE):
      self._handle_new_order_single(msg)
    elif (msg_type == MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST):
      self._handle_order_cancel_replace_request(msg)
    elif (msg_type == MSGTYPE_ORDER_CANCEL_REQUEST):
      self._handle_order_cancel_request(msg)
    else:
      # TODO: Add more `elif` cases and handle appropriately or log unknown type
      pass

  def _handle_new_order_single(self, msg: FixMessage) -> None:
    order = map_fix_message_to_order(msg, self._get_next_order_id())
    if (order.symbol not in self._instrument_order_books):
      self._instrument_order_books[order.symbol] = InstrumentOrderBook(
          order.symbol, self._process_outgoing_msg_to_gateway, self._process_outgoing_msg_to_ticker_plant)

    instrument_order_book: InstrumentOrderBook = self._instrument_order_books[order.symbol]
    instrument_order_book.process_new_order(order)

  # Handles requests for modifications to existing orders
  def _handle_order_cancel_replace_request(self, msg: FixMessage) -> None:
    if (not self._is_existing_order(msg.get(TAG_SYMBOL), msg.get(TAG_ORIGCLORDID))):
      logging.info('Rejecting Order Cancel Replace Request for unknown order id {}'.format(
          msg.get(TAG_ORIGCLORDID)))
      reject_msg = generate_order_cancel_reject_message(msg.get(TAG_SENDER_COMPID), 'NONE', msg.get(TAG_CLORDID), msg.get(
          TAG_ORIGCLORDID), ORDSTATUS_REJECTED, REJ_RESPONSE_TO_ORD_CANCEL_REPLACE_REQUEST, CXLREJREASON_UNKNOWN_ORDER)
      return self._process_outgoing_msg_to_gateway(reject_msg)

    updated_order = map_fix_message_to_order(msg, '')
    updated_order.orig_client_order_id = msg.get(TAG_ORIGCLORDID).decode()
    instrument_order_book: InstrumentOrderBook = self._instrument_order_books[
        updated_order.symbol]
    instrument_order_book.process_order_modification_request(updated_order)

  # Handles requests to cancel all of the remaining quantity of existing order
  def _handle_order_cancel_request(self, msg: FixMessage) -> None:
    if (not self._is_existing_order(msg.get(TAG_SYMBOL), msg.get(TAG_ORIGCLORDID))):
      logging.info('Rejecting Order Cancel Request for unknown order id {}'.format(
          msg.get(TAG_ORIGCLORDID)))
      reject_msg = generate_order_cancel_reject_message(msg.get(TAG_SENDER_COMPID), 'NONE', msg.get(TAG_CLORDID), msg.get(
          TAG_ORIGCLORDID), ORDSTATUS_REJECTED, REJ_RESPONSE_TO_ORD_CANCEL_REQUEST, CXLREJREASON_UNKNOWN_ORDER)
      return self._process_outgoing_msg_to_gateway(reject_msg)

    orig_client_order_id = msg.get(TAG_ORIGCLORDID).decode()
    client_order_id = msg.get(TAG_CLORDID).decode()
    symbol = msg.get(TAG_SYMBOL).decode()
    side = OrderSide.BUY if msg.get(TAG_SIDE) == SIDE_BUY else OrderSide.SELL
    instrument_order_book: InstrumentOrderBook = self._instrument_order_books[symbol]
    instrument_order_book.process_order_cancellation_request(
        orig_client_order_id, client_order_id, symbol, side)

  # Does NOT assign sequence numbers (since gateway keeps track of that for each client) + sending time
  def _process_outgoing_msg_to_gateway(self, msg: FixMessage) -> None:
    if (msg.get(TAG_MSGTYPE) == MSGTYPE_EXECUTION_REPORT):
      msg.append_pair(TAG_EXECID, self._get_next_exec_id())

    client_id: bytes = msg.get(TAG_TARGET_COMPID)
    self._send_msg_to_gateway(msg.encode(), client_id)

  def _process_outgoing_msg_to_ticker_plant(self) -> None:
    # TODO: Implement + update function signature
    pass

  def _is_existing_order(self, symbol: bytes, client_order_id: bytes) -> bool:
    decoded_symbol = symbol.decode()
    decoded_client_order_id = client_order_id.decode()
    return (
        decoded_symbol in self._instrument_order_books and
        self._instrument_order_books[decoded_symbol].contains_order(
            decoded_client_order_id)
    )

  def _get_next_order_id(self) -> str:
    self._curr_order_id += 1
    return str(self._curr_order_id)

  def _get_next_exec_id(self) -> int:
    self._curr_exec_id += 1
    return self._curr_exec_id
