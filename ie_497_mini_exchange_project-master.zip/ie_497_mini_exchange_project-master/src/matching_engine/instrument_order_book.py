import logging
from collections import deque
from typing import Any, Callable

from simplefix.constants import *
from simplefix.message import FixMessage
from sortedcontainers.sorteddict import SortedDict

from src.common.constants import *

from .model.order import Order, OrderSide, OrderStatus, OrderTrade
from .utils import *

# TODO: Sort secondary level of SortedDict according to timestamps assigned by the gateway
# TODO: Mention bundling is best/recommended practice + notify ticker plant even if new order never rests on the order book? + who to favor for pricing?
# TODO: Add specific type to ticker function + Can just have 1 `send_outgoing_msg` function that takes a dest parameter
# TODO: Unit tests + refactoring + extract common non-class specific code to `utils` + 'gateway' -> 'client'?
# TODO: Use `remaining_quantity` when sending appropriate updates to ticker plant


class InstrumentOrderBook:
  def __init__(self, instrument: str, send_msg_to_gateway: Callable[[FixMessage], None], send_msg_to_ticker_plant: Callable[[Any], None]):
    self._instrument = instrument
    self._send_msg_to_gateway = send_msg_to_gateway
    self._send_msg_to_ticker_plant = send_msg_to_ticker_plant
    self._orders = dict()
    # Since we want bids to be sorted in descending order, invert key for comparison purposes
    self._bids: SortedDict = SortedDict(lambda price: -1 * price)
    self._asks: SortedDict = SortedDict()

  def process_new_order(self, order: Order) -> None:
    if (order.symbol != self._instrument):
      return
    elif (order.client_order_id in self._orders):
      existing_order: Order = self._orders[order.client_order_id]
      return self._send_execution_report_to_gateway(
          existing_order, fill=False, exec_type=EXECTYPE_REJECTED, reject_reason=ORDERREJREASON_DUPLICATE_ORDER)

    self._orders[order.client_order_id] = order
    self._send_order_update_to_ticker_plant(order)
    num_orders_matched = self._try_order_match(order)

    if (order.order_status == OrderStatus.NEW or order.order_status == OrderStatus.PARTIALLY_FILLED):
      self._add_order_to_book(order)
    self._send_execution_report_to_gateway(
        order, fill=(num_orders_matched > 0), exec_type=EXECTYPE_NEW)

  # Assumes `orig_client_order_id` in `updated_order` refers to valid, existing order
  def process_order_modification_request(self, updated_order: Order) -> None:
    original_order: Order = self._orders[updated_order.orig_client_order_id]
    modification_reject_reason = self._get_modification_reject_reason(
        original_order, updated_order)

    if (modification_reject_reason is None):
      # Copy attributes from original order to updated order
      updated_order.order_id = original_order.order_id
      updated_order.trades = original_order.trades
      previously_filled_quantity = (
          original_order.quantity - original_order.remaining_quantity)
      # "Requests to replace the OrderQty to a level less than the CumQty will be interpreted by the broker as requests to stop executing the order"
      if (updated_order.quantity <= previously_filled_quantity):
        updated_order.order_status = OrderStatus.FILLED
        updated_order.remaining_quantity = 0
      else:
        updated_order.order_status = OrderStatus.REPLACED if original_order.order_status == OrderStatus.NEW else OrderStatus.PARTIALLY_FILLED
        updated_order.remaining_quantity = (
            updated_order.quantity - previously_filled_quantity)

      # Update order in internal record + send notification to ticker plant
      del self._orders[original_order.client_order_id]
      self._orders[updated_order.client_order_id] = updated_order
      self._send_order_update_to_ticker_plant(updated_order)

      # Update order in order book + try order matching (if appropriate)
      if (original_order.order_status != OrderStatus.FILLED):
        self._remove_order_from_book(original_order)

      num_orders_matched = 0
      if (updated_order.order_status != OrderStatus.FILLED):
        num_orders_matched = self._try_order_match(updated_order)
        if (updated_order.order_status == OrderStatus.REPLACED or updated_order.order_status == OrderStatus.PARTIALLY_FILLED):
          self._add_order_to_book(updated_order)
      self._send_execution_report_to_gateway(updated_order, fill=(
          num_orders_matched > 0), exec_type=EXECTYPE_REPLACE)
    else:
      logging.info('Rejecting order modification request {} for {} due to {}'.format(
          updated_order, original_order, modification_reject_reason))
      reject_msg = generate_order_cancel_reject_message(original_order.client_id, original_order.order_id, updated_order.client_order_id,
                                                        updated_order.orig_client_order_id, original_order.order_status, REJ_RESPONSE_TO_ORD_CANCEL_REPLACE_REQUEST, modification_reject_reason)
      self._send_msg_to_gateway(reject_msg)

  # Assumes `client_order_id` refers to a valid, existing order
  def process_order_cancellation_request(
      self, orig_client_order_id: str, client_order_id: str, symbol: str, side: OrderSide
  ) -> None:
    order: Order = self._orders[orig_client_order_id]
    cancellation_reject_reason = self._get_cancellation_reject_reason(
        order, symbol, side)

    if (cancellation_reject_reason is None):
      order.order_status = OrderStatus.CANCELED
      order.orig_client_order_id = orig_client_order_id
      order.client_order_id = client_order_id

      del self._orders[orig_client_order_id]
      self._orders[client_order_id] = order
      self._remove_order_from_book(order)
      self._send_execution_report_to_gateway(order)
      self._send_order_update_to_ticker_plant(order)
    else:
      logging.info('Rejecting order cancellation request for {} due to {}'.format(
          order, cancellation_reject_reason))
      reject_msg = generate_order_cancel_reject_message(order.client_id, order.order_id, client_order_id,
                                                        orig_client_order_id, order.order_status, REJ_RESPONSE_TO_ORD_CANCEL_REQUEST, cancellation_reject_reason)
      self._send_msg_to_gateway(reject_msg)

  def contains_order(self, client_order_id: str) -> bool:
    return (client_order_id in self._orders)

  def _try_order_match(self, order: Order) -> int:
    matched_orders = self._get_matched_orders(order)
    if (len(matched_orders) > 0):
      self._process_matched_orders(order, matched_orders)
      bundled_trade = bundle_most_recent_trades(matched_orders)
      order.trades.append(bundled_trade)
      order.remaining_quantity -= bundled_trade.quantity
      order.order_status = OrderStatus.FILLED if order.remaining_quantity == 0 else OrderStatus.PARTIALLY_FILLED
      self._send_order_update_to_ticker_plant(order)
    return len(matched_orders)

  # TODO: Remove `deque` object from bids or asks if all orders at that price filled?
  def _get_matched_orders(self, order: Order) -> list:
    remaining_quantity = order.remaining_quantity
    matched_orders = list()
    other_side_prices = self._asks.keys(
    ) if order.side == OrderSide.BUY else self._bids.keys()
    other_side_orders = self._asks if order.side == OrderSide.BUY else self._bids
    curr_index = 0

    while (remaining_quantity > 0 and curr_index < len(other_side_prices) and is_price_acceptable(order, other_side_prices[curr_index])):
      other_side_orders_at_price: deque = other_side_orders[other_side_prices[curr_index]]
      while (remaining_quantity > 0 and len(other_side_orders_at_price) > 0):
        matched_order: Order = other_side_orders_at_price[0]

        if (remaining_quantity >= matched_order.remaining_quantity):
          remaining_quantity -= matched_order.remaining_quantity
          matched_order.trades.append(OrderTrade(
              price=matched_order.price, quantity=matched_order.remaining_quantity))
          matched_order.remaining_quantity = 0
          matched_order.order_status = OrderStatus.FILLED
          other_side_orders_at_price.popleft()
        else:
          matched_order.trades.append(OrderTrade(
              price=matched_order.price, quantity=remaining_quantity))
          matched_order.remaining_quantity -= remaining_quantity
          matched_order.order_status = OrderStatus.PARTIALLY_FILLED
          remaining_quantity = 0

        matched_orders.append(matched_order)
      curr_index += 1

    return matched_orders

  # TODO: Would it be better to do this while doing the order matching?
  def _process_matched_orders(self, order: Order, matched_orders: list) -> None:
    # For each matched_order, send execution report to gateway + notify ticker plant of trade + update ticker plant with new bids/asks?
    for matched_order in matched_orders:
      self._send_execution_report_to_gateway(matched_order, fill=True)
      self._send_trade_message_to_ticker_plant(matched_order, order)
      self._send_order_update_to_ticker_plant(matched_order)

  def _add_order_to_book(self, order: Order) -> None:
    if (order.side == OrderSide.BUY):
      bids_at_price: deque = self._bids.get(order.price, deque())
      bids_at_price.append(order)
      self._bids[order.price] = bids_at_price
    else:
      asks_at_price: deque = self._asks.get(order.price, deque())
      asks_at_price.append(order)
      self._asks[order.price] = asks_at_price

  def _remove_order_from_book(self, order: Order) -> None:
    orders_on_side = self._bids if order.side == OrderSide.BUY else self._asks
    orders_at_price: deque = orders_on_side.get(order.price, deque())
    try:
      orders_at_price.remove(order)
    except ValueError:
      logging.error(
          'Order to remove {} does not exist in order book'.format(order))

  def _get_modification_reject_reason(self, original_order: Order, updated_order: Order) -> bytes:
    if (updated_order.symbol != original_order.symbol or updated_order.side != original_order.side):
      return CXLREJREASON_BROKER_OPTION
    elif (
        original_order.order_status == OrderStatus.CANCELED or original_order.order_status == OrderStatus.REJECTED or
        (original_order.order_status == OrderStatus.FILLED and (updated_order.price !=
                                                                original_order.price or updated_order.quantity < original_order.quantity))
    ):
      return CXLREJREASON_TOO_LATE_TO_CANCEL
    elif (original_order.order_status == OrderStatus.PENDING_CANCEL or original_order.order_status == OrderStatus.PENDING_REPLACE):
      return CXLREJREASON_ORDER_ALREADY_PENDING_CANCEL

    return None

  def _get_cancellation_reject_reason(self, original_order: Order, symbol: str, side: OrderSide) -> bytes:
    if (symbol != original_order.symbol or side != original_order.side):
      return CXLREJREASON_BROKER_OPTION
    elif (original_order.order_status == OrderStatus.PENDING_CANCEL):
      return CXLREJREASON_ORDER_ALREADY_PENDING_CANCEL
    elif (original_order.order_status == OrderStatus.FILLED):
      return CXLREJREASON_TOO_LATE_TO_CANCEL

    return None

  def _send_execution_report_to_gateway(self, order: Order, fill: bool = False, **kwargs: dict) -> None:
    # Generate FIX message, log it, and send it to gateway (i.e. add it to outgoing msg queue)
    execution_report = generate_execution_report_message(order, fill, **kwargs)
    # TODO: Log here or in server?
    logging.info(
        'Sending ExecutionReport message {} to gateway'.format(execution_report.encode()))
    self._send_msg_to_gateway(execution_report)

  def _send_order_update_to_ticker_plant(self, order: Order):
    # Generate FIX message, log it, and send it to ticker plant (i.e. add it to outgoing msg queue)
    # Either new bid/ask or removed bid/ask
    pass

  def _send_trade_message_to_ticker_plant(self, orderA: Order, orderB: Order):
    pass

  def __str__(self):
    order_book_str = ''

    buy_orders = list()
    for orders in self._bids.values():
      for order in orders:
        buy_orders.append(str(order))

    if (len(buy_orders) > 0):
      order_book_str += 'BUYS: {}'.format(',\n'.join(buy_orders)) + '\n'

    sell_orders = list()
    for orders in self._asks.values():
      for order in orders:
        sell_orders.append(str(order))

    if (len(sell_orders) > 0):
      order_book_str += 'SELLS: {}'.format(',\n'.join(sell_orders)) + '\n'
    return order_book_str
