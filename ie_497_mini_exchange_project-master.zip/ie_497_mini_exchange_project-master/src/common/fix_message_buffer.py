class FixMessageBuffer:
  def __init__(self):
    self._buffer = bytearray()
    self._expected_msg_length = -1

  def append(self, data: bytes) -> None:
    self._buffer += data

  def set_expected_msg_length(self, expected_msg_length: int) -> None:
    self._expected_msg_length = expected_msg_length

  def get_content(self) -> bytes:
    return bytes(self._buffer)

  def get_expected_msg_length(self) -> int:
    return self._expected_msg_length

  def is_empty(self) -> bool:
    return len(self._buffer) == 0

  def __len__(self) -> int:
    return len(self._buffer)

  def reset(self) -> None:
    self._buffer.clear()
    self._expected_msg_length = -1
