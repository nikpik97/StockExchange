import logging
import select
import socket
from abc import ABC, abstractmethod
from errno import EAGAIN, EWOULDBLOCK

from .constants import BUFFER_SIZE, READ_ONLY


class TCPServer(ABC):
  def __init__(self, server_address: tuple, backlog: int):
    # Create and initialize non-blocking TCP/IP socket for server
    self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    self._server_socket.setblocking(False)
    self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self._server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    self._server_socket.bind(server_address)
    self._server_socket.listen(backlog)

    # Set up the poller
    self._poller = select.epoll()
    self._poller.register(self._server_socket.fileno(), READ_ONLY)

  def serve_forever(self) -> None:
    while True:
      events = self._poller.poll()

      for fd, flag in events:
        if (flag & (select.POLLIN | select.POLLPRI)):
          if (fd == self._server_socket.fileno()):
            # New TCP connection
            self._handle_new_connection()
          else:
            # Socket is ready to send data to us
            self._handle_pollin_event(fd)
        elif (flag & select.POLLHUP):
          # Connection hung up
          self._handle_socket_disconnect(fd, result_of_error=False)
        elif flag & select.POLLOUT:
          # Socket is ready to receive data from us
          self._handle_pollout_event(fd)
        elif flag & select.POLLERR:
          # Error occurred on fd
          self._handle_socket_disconnect(fd, result_of_error=True)

  def _read_data_from_socket(self, sock: socket.socket) -> bytes:
    received_data = bytearray()
    did_error_occur = False
    can_read_more_data = True

    while (can_read_more_data):
      try:
        data = sock.recv(BUFFER_SIZE)
        if (not data):
          can_read_more_data = False
        else:
          received_data += data
      except socket.error as err:
        if (err.errno != EWOULDBLOCK and err.errno != EAGAIN):
          logging.exception(
              'Exception occurred while reading data from socket: {}'.format(sock.getpeername()))
          did_error_occur = True
        can_read_more_data = False

    # Interpret empty result as closed connection
    if (did_error_occur or len(received_data) == 0):
      logging.info(
          'Connection with {} closed. Performing cleanup'.format(sock.getpeername()))
      self._shutdown_socket(sock)

    return bytes(received_data)

  @abstractmethod
  def _handle_new_connection(self) -> None:
    pass

  @abstractmethod
  def _handle_pollin_event(self, fd: int) -> None:
    pass

  @abstractmethod
  def _handle_pollout_event(self, fd: int) -> None:
    pass

  @abstractmethod
  def _handle_socket_disconnect(self, fd: int, result_of_error: bool) -> None:
    pass

  @abstractmethod
  def _shutdown_socket(self, sock: socket.socket) -> None:
    if (sock.fileno() != -1):
      self._poller.unregister(sock.fileno())
      sock.shutdown(socket.SHUT_RDWR)
      sock.close()

  @abstractmethod
  def shutdown(self) -> None:
    self._poller.unregister(self._server_socket.fileno())
    self._poller.close()
    self._server_socket.shutdown(socket.SHUT_RDWR)
    self._server_socket.close()
