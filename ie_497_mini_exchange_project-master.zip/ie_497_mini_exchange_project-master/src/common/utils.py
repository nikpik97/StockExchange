from datetime import datetime

from simplefix.constants import *
from simplefix.message import FixMessage
from simplefix.parser import FixParser

from .constants import (CHECKSUM_TAG_VALUE_LENGTH, EXCHANGE_COMP_ID,
                        FIX_BEGIN_STRING, SOH, TIMESTAMP_FORMAT)
from .fix_message_buffer import FixMessageBuffer


def parse_fix_messages(data: bytes, buffer: FixMessageBuffer) -> list:
  parsed_messages = list()
  fix_parser = FixParser()

  while (len(data) > 0):
    if (buffer.is_empty()):
      if (data.count(SOH) < 2):
        buffer.append(data)
        return parsed_messages

      start_index = data.index(SOH)
      end_index = data.index(SOH, start_index + 1)
      body_length_tag_value = data[start_index + 1: end_index]
      # TODO: Make safer (what if malformed message and int() call throws exception?)
      body_length = int(body_length_tag_value[2:])

      total_expected_msg_len = end_index + 1 + \
          body_length + CHECKSUM_TAG_VALUE_LENGTH
      if (len(data) >= total_expected_msg_len):
        fix_parser.append_buffer(data[:total_expected_msg_len])
        parsed_msg = fix_parser.get_message()
        if (parsed_msg is not None):
          parsed_messages.append(parsed_msg)
          data = data[total_expected_msg_len:]
          fix_parser.reset()
          continue
      else:
        buffer.append(data)
        buffer.set_expected_msg_length(
            total_expected_msg_len)
        return parsed_messages
    elif (buffer.get_expected_msg_length() != -1):
      total_expected_msg_len = buffer.get_expected_msg_length()
      remaining_msg_len = total_expected_msg_len - \
          len(buffer)

      if (len(data) >= remaining_msg_len):
        fix_parser.append_buffer(
            buffer.get_content())
        fix_parser.append_buffer(data[:remaining_msg_len])
        parsed_msg = fix_parser.get_message()
        if (parsed_msg is not None):
          parsed_messages.append(parsed_msg)
          data = data[remaining_msg_len:]
          fix_parser.reset()
          buffer.reset()
          continue
      else:
        buffer.append(data)
        return parsed_messages
    else:
      # TODO: Implement case where buffer has some data but expected_msg_length unknown
      pass

  return parsed_messages


def create_msg_with_header(msg_type: bytes, client_id: bytes) -> FixMessage:
  """Helper function to generate a new FixMessage with parts of StandardHeader pre-filled"""
  msg = FixMessage()
  msg.append_pair(TAG_BEGINSTRING, FIX_BEGIN_STRING)
  msg.append_pair(TAG_MSGTYPE, msg_type)
  msg.append_pair(TAG_SENDER_COMPID, EXCHANGE_COMP_ID)
  msg.append_pair(TAG_TARGET_COMPID, client_id)
  return msg


def is_float(value: bytes) -> bool:
  try:
    float(value)
  except ValueError:
    return False
  return True


def is_int(value: bytes) -> bool:
  try:
    int(value)
  except ValueError:
    return False
  return True


def is_valid_timestamp(value: bytes, format: str = TIMESTAMP_FORMAT) -> bool:
  if (value is None):
    return False

  try:
    datetime.strptime(value.decode(), format)
  except (ValueError, TypeError) as err:
    return False
  return True
