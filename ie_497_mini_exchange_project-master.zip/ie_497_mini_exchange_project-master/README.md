# Mini-Exchange Project Overview

As part of our final project for IE 497 @ University of Illinois, we created a Mini-Exchange to apply the principles that we had learned in the class. The exchange consists of:

1. Gateway
2. Order matching engine
3. Ticker plant

The Gateway and Ticker Plant follow the [FIX](https://en.wikipedia.org/wiki/Financial_Information_eXchange) version 4.2 protocol.

# Technical Details

**TODO**: Add more information about running the project + other technical details

- Style Guide: PEP8

# Team:

- Abdul Bagasarawala (NetID: abagas3)
- Nikhil Paidipally (NetID: npaidi2)
- Jason (Xingjian) Gong (NetID: xg8)
