import unittest
from src.gateway.utils import *

from simplefix.parser import FixParser
from simplefix.constants import *


class GatewayUtilsTest(unittest.TestCase):
  # ------------------ Unit Tests for `validate_fix_message` ------------------
  def test_valid_logon_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=6935=A34=149=EXEC52=20121105-23:24:06.00056=SimpleExchange98=0108=3010=003')
    logon_message = parser.get_message()
    self.assertEqual(validate_fix_message(logon_message, '', 1), (None, None))

  def test_valid_heartbeat_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=5735=034=249=EXEC52=20121105-23:24:37.056=SimpleExchange10=228')
    heartbeat_message = parser.get_message()
    self.assertEqual(validate_fix_message(
        heartbeat_message, b'EXEC', 2), (None, None))

  def test_valid_new_order_single_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=10010=064')
    new_order_single_message = parser.get_message()
    self.assertEqual(validate_fix_message(
        new_order_single_message, b'EXEC', 3), (None, None))

  def test_message_without_type(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=5134=149=EXEC52=20121105-23:24:37.056=SimpleExchange10=228')
    message_without_type = parser.get_message()
    self.assertEqual(validate_fix_message(message_without_type, b'EXEC', 1),
                     (SESSIONREJECTREASON_INVALID_MSGTYPE, TAG_MSGTYPE))

  def test_invalid_message_type(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=5835=-134=149=EXEC52=20121105-23:24:37.056=SimpleExchange10=228')
    invalid_message_type = parser.get_message()
    self.assertEqual(validate_fix_message(invalid_message_type, b'EXEC', 1),
                     (SESSIONREJECTREASON_INVALID_MSGTYPE, TAG_MSGTYPE))

  def test_fix_version_mismatch(self):
    parser = FixParser()
    # Our FIX engine only supports FIX 4.2 (NOT 4.1 as in message below)
    parser.append_buffer(
        b'8=FIX.4.19=5735=034=149=EXEC52=20121105-23:24:37.056=SimpleExchange10=228')
    mismatched_fix_version_message = parser.get_message()
    self.assertEqual(validate_fix_message(mismatched_fix_version_message, b'EXEC', 1),
                     (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_BEGINSTRING))

  def test_sender_comp_id_mismatch(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=6035=034=149=INVALID52=20121105-23:24:37.056=SimpleExchange10=228')
    mismatched_sender_comp_id_msg = parser.get_message()
    self.assertEqual(validate_fix_message(mismatched_sender_comp_id_msg,
                                          b'EXEC', 1), (SESSIONREJECTREASON_COMPID_PROBLEM, TAG_SENDER_COMPID))

  def test_target_comp_id_mismatch(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=5335=034=149=EXEC52=20121105-23:24:37.056=INVALID10=228')
    mismatched_target_comp_id_msg = parser.get_message()
    self.assertEqual(validate_fix_message(mismatched_target_comp_id_msg,
                                          b'EXEC', 1), (SESSIONREJECTREASON_COMPID_PROBLEM, TAG_TARGET_COMPID))

  def test_msg_seq_num_mismatch(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=5735=034=549=EXEC52=20121105-23:24:37.056=SimpleExchange10=228')
    mismatched_seq_num_msg = parser.get_message()
    self.assertEqual(validate_fix_message(
        mismatched_seq_num_msg, b'EXEC', 1), (SESSIONREJECTREASON_OTHER, TAG_MSGSEQNUM))

  def test_corrupted_msg_seq_num(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=6535=034=corrupted49=EXEC52=20121105-23:24:37.056=SimpleExchange10=228')
    corrupted_seq_num_msg = parser.get_message()
    self.assertEqual(validate_fix_message(
        corrupted_seq_num_msg, b'EXEC', 1), (SESSIONREJECTREASON_OTHER, TAG_MSGSEQNUM))

  def test_unspecified_sending_time(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=3635=034=149=EXEC56=SimpleExchange10=228')
    unspecified_sending_time_msg = parser.get_message()
    self.assertEqual(validate_fix_message(
        unspecified_sending_time_msg, b'EXEC', 1), (SESSIONREJECTREASON_SENDINGTIME_ACCURACY_PROBLEM, TAG_SENDING_TIME))

  # Constructed message is missing required "Heartbeat Interval" value
  def test_invalid_logon_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=6235=A34=149=EXEC52=20121105-23:24:06.056=SimpleExchange98=010=003')
    invalid_logon_message = parser.get_message()
    self.assertEqual(validate_fix_message(invalid_logon_message, b'', 1),
                     (SESSIONREJECTREASON_REQUIRED_TAG_MISSING, TAG_HEARTBTINT))

  def test_empty_sender_comp_id_logon_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=5835=A34=152=20121105-23:24:06.056=SimpleExchange98=010=003')
    empty_sender_comp_id_msg = parser.get_message()
    self.assertEqual(validate_fix_message(empty_sender_comp_id_msg, b'', 1),
                     (SESSIONREJECTREASON_COMPID_PROBLEM, TAG_SENDER_COMPID))

  # Constructed message is missing required "Order Quantity" value
  def test_invalid_new_order_single_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=13935=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750640=244=10010=064')
    invalid_new_order_single_message = parser.get_message()
    self.assertEqual(validate_fix_message(invalid_new_order_single_message, b'EXEC', 3),
                     (SESSIONREJECTREASON_REQUIRED_TAG_MISSING, TAG_ORDERQTY))

  # ------------------ Unit Tests for `validate_fix_order_message` ------------------
  def test_valid_new_order_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=10010=064')
    new_order_single_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        new_order_single_msg), (None, None))

  def test_valid_order_replace_message(self):
    parser = FixParser()
    parser.append_buffer(b'8=FIX.4.29=17735=G34=352=20190513-11:34:11.90299349=CLIB56=SimpleExchange11=client_b_new_order_id41=client_b_order_id21=155=MSFT54=260=20190513-11:34:11.90296138=5040=244=125.4610=214')
    order_replace_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        order_replace_msg), (None, None))

  def test_valid_order_cancel_message(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=15635=F34=352=20190514-06:32:00.65153549=SimpleExchange49=CLIA56=SimpleExchange11=cancel_order41=135215788257755=MSFT54=160=20190514-06:32:50.63862810=155')
    order_cancel_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        order_cancel_msg), (None, None))

  def test_new_order_message_no_symbol(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=154=160=20190507-08:16:24.54750638=100040=244=10010=064')
    no_symbol_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        no_symbol_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_SYMBOL))

  def test_new_order_message_invalid_side(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=Z60=20190507-08:16:24.54750638=100040=244=10010=064')
    invalid_side_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        invalid_side_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_SIDE))

  def test_new_order_message_invalid_transact_time(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=invalid_time38=100040=244=10010=064')
    invalid_transact_time_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        invalid_transact_time_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_TRANSACTTIME))

  def test_new_order_message_non_numeric_qty(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=abcd40=244=10010=064')
    non_numeric_qty_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        non_numeric_qty_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_ORDERQTY))

  def test_new_order_message_zero_qty(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=040=244=10010=064')
    zero_qty_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        zero_qty_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_ORDERQTY))

  def test_new_order_message_unsupported_order_type(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=544=10010=064')
    unsupported_order_type_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        unsupported_order_type_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_ORDTYPE))

  def test_new_order_message_non_numeric_price(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=abc10=064')
    non_numeric_price_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        non_numeric_price_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_PRICE))

  def test_new_order_message_negative_price(self):
    parser = FixParser()
    parser.append_buffer(
        b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=-1010=064')
    negative_price_msg = parser.get_message()
    self.assertEqual(validate_fix_order_message(
        negative_price_msg), (SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG, TAG_PRICE))


if __name__ == "__main__":
  unittest.main()
