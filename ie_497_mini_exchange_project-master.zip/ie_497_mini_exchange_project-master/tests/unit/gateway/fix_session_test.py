import unittest
from collections import deque

from simplefix.constants import *
from simplefix.parser import FixParser

from src.gateway.fix_session import *


class FixSessionTest(unittest.TestCase):
  def test_valid_client_logon(self):
    client_outgoing_msg_queue = deque()
    ome_outgoing_msg_queue = None
    fix_session = FixSession(client_outgoing_msg_queue, ome_outgoing_msg_queue)
    logon_msg = b'8=FIX.4.29=7335=A34=149=EXEC52=20121105-23:24:06.00056=SimpleExchange98=0108=3010=003'

    fix_session.process_data_from_client(logon_msg)
    self.assertTrue(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 1)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 2)
    self.assertEqual(fix_session._heartbeat_interval, 30)
    self.assertEqual(fix_session._client_comp_id, b'EXEC')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)

    encoded_logon_ack_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_logon_ack_msg)
    parser = FixParser()
    parser.append_buffer(encoded_logon_ack_msg)
    logon_ack_message = parser.get_message()

    self.assertIsNotNone(logon_ack_message)
    self._validate_fix_message_header(
        logon_ack_message, MSGTYPE_LOGON, b'EXEC', 1)
    self.assertEqual(logon_ack_message.get(
        TAG_ENCRYPTMETHOD), ENCRYPTMETHOD_NONE)
    self.assertEqual(logon_ack_message.get(TAG_HEARTBTINT), b'30')

  def test_invalid_client_logon(self):
    client_outgoing_msg_queue = deque()
    ome_outgoing_msg_queue = None
    fix_session = FixSession(client_outgoing_msg_queue, ome_outgoing_msg_queue)
    # Invalid since MsgSeqNum (Tag 34) != 1
    invalid_logon = b'8=FIX.4.29=7335=A34=249=EXEC52=20121105-23:24:06.00056=SimpleExchange98=0108=3010=003'

    fix_session.process_data_from_client(invalid_logon)
    self.assertFalse(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 1)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 2)
    self.assertEqual(fix_session._heartbeat_interval, 0)
    self.assertEqual(fix_session._client_comp_id, b'')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 2)

    encoded_logout_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_logout_msg)
    parser = FixParser()
    parser.append_buffer(encoded_logout_msg)
    logout_msg = parser.get_message()
    self.assertIsNotNone(logout_msg)
    self._validate_fix_message_header(
        logout_msg, MSGTYPE_LOGOUT, b'UNKNOWN', 1)

    terminate_connection_msg: bytes = fix_session._client_outgoing_msg_queue[1]
    self.assertEqual(terminate_connection_msg, TERMINATE_CONNECTION_MSG)

  # Verifies that attempts to submit an order before Logon are rejected
  def test_new_order_from_unauthenticated_client(self):
    client_outgoing_msg_queue = deque()
    ome_outgoing_msg_queue = None
    fix_session = FixSession(client_outgoing_msg_queue, ome_outgoing_msg_queue)
    new_order_single_msg = b'8=FIX.4.29=14735=D34=152=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=10010=064'

    fix_session.process_data_from_client(new_order_single_msg)
    self.assertFalse(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 1)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 2)
    self.assertEqual(fix_session._heartbeat_interval, 0)
    self.assertEqual(fix_session._client_comp_id, b'')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 2)

    encoded_logout_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_logout_msg)
    parser = FixParser()
    parser.append_buffer(encoded_logout_msg)
    logout_msg = parser.get_message()
    self.assertIsNotNone(logout_msg)
    self._validate_fix_message_header(
        logout_msg, MSGTYPE_LOGOUT, b'UNKNOWN', 1)

    terminate_connection_msg: bytes = fix_session._client_outgoing_msg_queue[1]
    self.assertEqual(terminate_connection_msg, TERMINATE_CONNECTION_MSG)

  def test_new_valid_order_from_authenticated_client(self):
    fix_session = self._get_authenticated_fix_session()
    new_order_single_msg = b'8=FIX.4.29=14735=D34=252=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=10010=064'

    fix_session.process_data_from_client(new_order_single_msg)
    self.assertEqual(fix_session._incoming_msg_seq_num, 2)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 2)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 1)
    self.assertEqual(
        fix_session._ome_outgoing_msg_queue[0][:-CHECKSUM_TAG_VALUE_LENGTH], new_order_single_msg[:-CHECKSUM_TAG_VALUE_LENGTH])

    # Mock response from OME for testing purposes
    fix_session._ome_outgoing_msg_queue.clear()
    execution_report_msg = b'8=FIX.4.29=16635=849=SimpleExchange56=EXEC37=111=135215788257720=0150=039=055=MSFT54=138=100.044=125.56=0.014=0.060=20190513-11:17:31.17007532=031=0151=100.017=110=254'
    fix_session.process_data_from_ome(execution_report_msg)

    self.assertEqual(fix_session._incoming_msg_seq_num, 2)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 3)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)

    encoded_execution_report_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_execution_report_msg)
    parser = FixParser()
    parser.append_buffer(encoded_execution_report_msg)
    execution_report_fix_msg = parser.get_message()
    self.assertIsNotNone(execution_report_fix_msg)
    self._validate_fix_message_header(
        execution_report_fix_msg, MSGTYPE_EXECUTION_REPORT, b'EXEC', 2)

  def test_invalid_new_order_single_from_authenticated_client(self):
    fix_session = self._get_authenticated_fix_session()
    # Invalid since OrderQty (Tag 38) == 0
    invalid_new_order_single_msg = b'8=FIX.4.29=14435=D34=252=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=040=244=10010=064'

    fix_session.process_data_from_client(invalid_new_order_single_msg)
    self.assertEqual(fix_session._incoming_msg_seq_num, 2)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 3)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)

    encoded_reject_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_reject_msg)
    parser = FixParser()
    parser.append_buffer(encoded_reject_msg)
    reject_fix_msg = parser.get_message()
    self.assertIsNotNone(reject_fix_msg)
    self._validate_fix_message_header(
        reject_fix_msg, MSGTYPE_REJECT, b'EXEC', 2)
    self.assertEqual(reject_fix_msg.get(TAG_REFSEQNUM), b'2')
    self.assertEqual(reject_fix_msg.get(TAG_REF_TAG_ID), TAG_ORDERQTY)
    self.assertEqual(reject_fix_msg.get(
        TAG_REF_MSG_TYPE), MSGTYPE_NEW_ORDER_SINGLE)
    self.assertEqual(reject_fix_msg.get(TAG_SESSIONREJECTREASON),
                     SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG)

  def test_invalid_msg_from_authenticated_client(self):
    fix_session = self._get_authenticated_fix_session()
    invalid_msg = b'8=FIX.4.29=6035=-134=249=EXEC52=20121105-23:24:37.056=SimpleExchange10=228'

    fix_session.process_data_from_client(invalid_msg)
    self.assertEqual(fix_session._incoming_msg_seq_num, 2)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 3)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)

    encoded_reject_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_reject_msg)
    parser = FixParser()
    parser.append_buffer(encoded_reject_msg)
    reject_fix_msg = parser.get_message()
    self.assertIsNotNone(reject_fix_msg)
    self._validate_fix_message_header(
        reject_fix_msg, MSGTYPE_REJECT, b'EXEC', 2)
    self.assertEqual(reject_fix_msg.get(TAG_REFSEQNUM), b'2')
    self.assertEqual(reject_fix_msg.get(TAG_REF_TAG_ID), TAG_MSGTYPE)
    self.assertEqual(reject_fix_msg.get(TAG_REF_MSG_TYPE), b'-1')
    self.assertEqual(reject_fix_msg.get(TAG_SESSIONREJECTREASON),
                     SESSIONREJECTREASON_INVALID_MSGTYPE)

  # Send invalid order then valid order
  def test_invalid_order_then_valid_order(self):
    fix_session = self._get_authenticated_fix_session()
    invalid_new_order_single_msg = b'8=FIX.4.29=14435=D34=252=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=040=244=10010=064'

    fix_session.process_data_from_client(invalid_new_order_single_msg)
    self.assertEqual(fix_session._incoming_msg_seq_num, 2)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 3)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)

    encoded_reject_msg: bytes = fix_session._client_outgoing_msg_queue.pop()
    self.assertIsNotNone(encoded_reject_msg)
    parser = FixParser()
    parser.append_buffer(encoded_reject_msg)
    reject_fix_msg = parser.get_message()
    self.assertIsNotNone(reject_fix_msg)
    self._validate_fix_message_header(
        reject_fix_msg, MSGTYPE_REJECT, b'EXEC', 2)
    self.assertEqual(reject_fix_msg.get(TAG_REFSEQNUM), b'2')
    self.assertEqual(reject_fix_msg.get(TAG_REF_TAG_ID), TAG_ORDERQTY)
    self.assertEqual(reject_fix_msg.get(
        TAG_REF_MSG_TYPE), MSGTYPE_NEW_ORDER_SINGLE)
    self.assertEqual(reject_fix_msg.get(TAG_SESSIONREJECTREASON),
                     SESSIONREJECTREASON_VALUE_INCORRECT_FOR_THIS_TAG)

    new_order_single_msg = b'8=FIX.4.29=14735=D34=352=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=10010=064'
    fix_session.process_data_from_client(new_order_single_msg)
    self.assertEqual(fix_session._incoming_msg_seq_num, 3)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 3)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 1)
    self.assertEqual(
        fix_session._ome_outgoing_msg_queue[0][:-CHECKSUM_TAG_VALUE_LENGTH], new_order_single_msg[:-CHECKSUM_TAG_VALUE_LENGTH])

    # Mock response from OME for testing purposes
    fix_session._ome_outgoing_msg_queue.clear()
    execution_report_msg = b'8=FIX.4.29=16635=849=SimpleExchange56=EXEC37=111=135215788257720=0150=039=055=MSFT54=138=100.044=125.56=0.014=0.060=20190513-11:17:31.17007532=031=0151=100.017=110=254'
    fix_session.process_data_from_ome(execution_report_msg)

    self.assertEqual(fix_session._incoming_msg_seq_num, 3)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 4)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)

    encoded_execution_report_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_execution_report_msg)
    parser = FixParser()
    parser.append_buffer(encoded_execution_report_msg)
    execution_report_fix_msg = parser.get_message()
    self.assertIsNotNone(execution_report_fix_msg)
    self._validate_fix_message_header(
        execution_report_fix_msg, MSGTYPE_EXECUTION_REPORT, b'EXEC', 3)

  def test_batched_logon_new_order_messages(self):
    client_outgoing_msg_queue = deque()
    ome_outgoing_msg_queue = deque()
    fix_session = FixSession(client_outgoing_msg_queue, ome_outgoing_msg_queue)

    logon_msg = b'8=FIX.4.29=7335=A34=149=EXEC52=20121105-23:24:06.00056=SimpleExchange98=0108=3010=003'
    new_order_msg = b'8=FIX.4.29=14735=D34=252=20190507-08:16:24.54771549=EXEC56=SimpleExchange11=135215788257721=155=MSFT54=160=20190507-08:16:24.54750638=100040=244=10010=064'
    logon_and_new_order_msg = logon_msg + new_order_msg

    fix_session.process_data_from_client(logon_and_new_order_msg)
    self.assertTrue(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 2)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 2)
    self.assertEqual(fix_session._heartbeat_interval, 30)
    self.assertEqual(fix_session._client_comp_id, b'EXEC')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 1)

    encoded_logon_ack_msg: bytes = fix_session._client_outgoing_msg_queue.pop()
    self.assertIsNotNone(encoded_logon_ack_msg)
    parser = FixParser()
    parser.append_buffer(encoded_logon_ack_msg)
    logon_ack_message = parser.get_message()

    self.assertIsNotNone(logon_ack_message)
    self._validate_fix_message_header(
        logon_ack_message, MSGTYPE_LOGON, b'EXEC', 1)
    self.assertEqual(logon_ack_message.get(
        TAG_ENCRYPTMETHOD), ENCRYPTMETHOD_NONE)
    self.assertEqual(logon_ack_message.get(TAG_HEARTBTINT), b'30')

    self.assertEqual(
        fix_session._ome_outgoing_msg_queue.pop()[:-CHECKSUM_TAG_VALUE_LENGTH], new_order_msg[:-CHECKSUM_TAG_VALUE_LENGTH])
    # Mock response from OME for testing purposes
    execution_report_msg = b'8=FIX.4.29=16635=849=SimpleExchange56=EXEC37=111=135215788257720=0150=039=055=MSFT54=138=100.044=125.56=0.014=0.060=20190513-11:17:31.17007532=031=0151=100.017=110=254'
    fix_session.process_data_from_ome(execution_report_msg)

    self.assertEqual(fix_session._incoming_msg_seq_num, 2)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 3)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)

    encoded_execution_report_msg: bytes = fix_session._client_outgoing_msg_queue[0]
    self.assertIsNotNone(encoded_execution_report_msg)
    parser = FixParser()
    parser.append_buffer(encoded_execution_report_msg)
    execution_report_fix_msg = parser.get_message()
    self.assertIsNotNone(execution_report_fix_msg)
    self._validate_fix_message_header(
        execution_report_fix_msg, MSGTYPE_EXECUTION_REPORT, b'EXEC', 2)

  def test_message_split_across_packets(self):
    client_outgoing_msg_queue = deque()
    ome_outgoing_msg_queue = deque()
    fix_session = FixSession(client_outgoing_msg_queue, ome_outgoing_msg_queue)
    logon_msg_part_1 = b'8=FIX.4.29=7335=A34=1'
    logon_msg_part_2 = b'49=EXEC52=20121105-23:24:06.00056=SimpleExchange98=0108=3010=003'

    fix_session.process_data_from_client(logon_msg_part_1)
    self.assertFalse(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 1)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 1)
    self.assertEqual(fix_session._heartbeat_interval, 0)
    self.assertEqual(fix_session._client_comp_id, b'')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)

    fix_session.process_data_from_client(logon_msg_part_2)
    self.assertTrue(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 1)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 2)
    self.assertEqual(fix_session._heartbeat_interval, 30)
    self.assertEqual(fix_session._client_comp_id, b'EXEC')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 1)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)

    encoded_logon_ack_msg: bytes = fix_session._client_outgoing_msg_queue.pop()
    self.assertIsNotNone(encoded_logon_ack_msg)
    parser = FixParser()
    parser.append_buffer(encoded_logon_ack_msg)
    logon_ack_message = parser.get_message()

    self.assertIsNotNone(logon_ack_message)
    self._validate_fix_message_header(
        logon_ack_message, MSGTYPE_LOGON, b'EXEC', 1)
    self.assertEqual(logon_ack_message.get(
        TAG_ENCRYPTMETHOD), ENCRYPTMETHOD_NONE)
    self.assertEqual(logon_ack_message.get(TAG_HEARTBTINT), b'30')

  def test_empty_message_from_unauthenticated_client(self):
    client_outgoing_msg_queue = deque()
    ome_outgoing_msg_queue = deque()
    fix_session = FixSession(client_outgoing_msg_queue, ome_outgoing_msg_queue)

    fix_session.process_data_from_client(b'')
    self.assertFalse(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 1)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 1)
    self.assertEqual(fix_session._heartbeat_interval, 0)
    self.assertEqual(fix_session._client_comp_id, b'')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)

  def test_empty_message_from_authenticated_client(self):
    fix_session = self._get_authenticated_fix_session()
    fix_session.process_data_from_client(b'')
    self.assertTrue(fix_session._is_client_authenticated)
    self.assertEqual(fix_session._incoming_msg_seq_num, 1)
    self.assertEqual(fix_session._outgoing_msg_seq_num, 2)
    self.assertEqual(fix_session._heartbeat_interval, 30)
    self.assertEqual(fix_session._client_comp_id, b'EXEC')
    self.assertEqual(len(fix_session._client_outgoing_msg_queue), 0)
    self.assertEqual(len(fix_session._ome_outgoing_msg_queue), 0)

  def _get_authenticated_fix_session(self) -> FixSession:
    client_outgoing_msg_queue = deque()
    ome_outgoing_msg_queue = deque()
    fix_session = FixSession(client_outgoing_msg_queue, ome_outgoing_msg_queue)
    logon_message = b'8=FIX.4.29=7335=A34=149=EXEC52=20121105-23:24:06.00056=SimpleExchange98=0108=3010=003'
    fix_session.process_data_from_client(logon_message)
    fix_session._client_outgoing_msg_queue.clear()
    return fix_session

  def _validate_fix_message_header(self, msg: FixMessage, msg_type: bytes, client_id: bytes, expected_seq_num: int):
    self.assertEqual(msg.get(TAG_BEGINSTRING), FIX_BEGIN_STRING)
    self.assertEqual(msg.get(TAG_MSGTYPE), msg_type)
    self.assertEqual(msg.get(TAG_SENDER_COMPID), EXCHANGE_COMP_ID)
    self.assertEqual(msg.get(TAG_TARGET_COMPID), client_id)
    self.assertEqual(int(msg.get(TAG_MSGSEQNUM)), expected_seq_num)
    self.assertIsNotNone(msg.get(TAG_BODYLENGTH))
    self.assertIsNotNone(msg.get(TAG_SENDING_TIME))


if __name__ == "__main__":
  unittest.main()
