import os
import socket
from datetime import datetime

from simplefix.constants import *
from simplefix.message import FixMessage
from simplefix.parser import FixParser

from src.common.constants import *

from .constants import *
from .utils import *


# 2 clients submit BUY orders that should NOT match
def test_two_clients_no_fills():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new BUY order
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 23,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous order was also a BUY order
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)) == 0.0

  client_a.close()
  client_b.close()

# 2 clients submit orders for different symbols that should NOT match
def test_two_clients_different_symbols_no_fill():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new SELL order for different symbol (should NOT match)
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'FB',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 23,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 121.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous order was for different symbol
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)) == 0.0

  client_a.close()
  client_b.close()

# 1 client submits BUY order. Another submits SELL order. Both should get fully filled
def test_two_clients_full_fills():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B submits new SELL order (should match)
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 123.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be fully filled
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)
               ) >= client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)
               ) >= client_b_order_attrs.get(TAG_PRICE)

  # Client A should receive fill execution report
  encoded_execution_report_client_a_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_a_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_a_msg)
  execution_report_client_a_msg = parser.get_message()
  assert execution_report_client_a_msg is not None
  validate_fix_message_header(
      execution_report_client_a_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert execution_report_client_a_msg.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert execution_report_client_a_msg.get(
      TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_client_a_msg.get(TAG_EXECID) is not None
  assert execution_report_client_a_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_client_a_msg.get(TAG_EXECTYPE) == EXECTYPE_FILL
  assert execution_report_client_a_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_client_a_msg.get(
      TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_a_msg.get(
      TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_a_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_a_msg.get(TAG_LASTQTY)
               ) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_LASTPX)
               ) <= order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_a_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_client_a_msg.get(TAG_CUMQTY)
               ) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_AVGPX)
               ) <= order_attrs.get(TAG_PRICE)

  client_a.close()
  client_b.close()


# 1 client submits SELL order. Another submits BUY order. One gets fully filled. Another gets partially filled
def test_two_clients_partial_fill():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new SELL order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'FB',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 1200.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 190.72
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new BUY order (should get fully filled)
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'FB',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 158.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 191.83
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be fully filled since it should match with client A's order
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)
               ) <= client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)
               ) <= client_b_order_attrs.get(TAG_PRICE)

  # Client A should receive partial fill execution report
  encoded_execution_report_client_a_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_a_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_a_msg)
  execution_report_client_a_msg = parser.get_message()
  assert execution_report_client_a_msg is not None
  validate_fix_message_header(
      execution_report_client_a_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert execution_report_client_a_msg.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert execution_report_client_a_msg.get(
      TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_client_a_msg.get(TAG_EXECID) is not None
  assert execution_report_client_a_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_client_a_msg.get(
      TAG_EXECTYPE) == EXECTYPE_PARTIAL_FILL
  assert execution_report_client_a_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_PARTIALLY_FILLED
  assert execution_report_client_a_msg.get(
      TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_a_msg.get(
      TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_a_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_a_msg.get(TAG_LASTQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_LASTPX)
               ) >= order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_a_msg.get(
      TAG_LEAVES_QTY)) == (order_attrs.get(TAG_ORDERQTY) - client_b_order_attrs.get(TAG_ORDERQTY))
  assert float(execution_report_client_a_msg.get(TAG_CUMQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_AVGPX)
               ) >= order_attrs.get(TAG_PRICE)

  client_a.close()
  client_b.close()


# 2 clients submit orders that partially match AFTER client A increases his buy price
def test_two_clients_partial_fill_after_replace_order():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new SELL order (should NOT match)
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 1500.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous order's price does not match
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)) == 0.0

  # Client A submits replace request increasing buy price + lowering quantity (should get fully filled)
  replace_order_attrs = {
      TAG_ORIGCLORDID: order_attrs.get(TAG_CLORDID),
      TAG_CLORDID: b'CLIA-1-Replaced',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 53.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.2
  }
  replace_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST, client_a_comp_id, 3)
  for tag, value in replace_order_attrs.items():
    replace_order_msg.append_pair(tag, value)
  encoded_replace_order_msg = replace_order_msg.encode()

  client_a.sendall(encoded_replace_order_msg)
  encoded_replace_er_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_replace_er_msg != b''
  parser.reset()
  parser.append_buffer(encoded_replace_er_msg)
  replace_execution_report = parser.get_message()
  assert replace_execution_report is not None
  validate_fix_message_header(
      replace_execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert replace_execution_report.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert replace_execution_report.get(
      TAG_ORIGCLORDID) == replace_order_attrs.get(TAG_ORIGCLORDID)
  assert replace_execution_report.get(
      TAG_CLORDID) == replace_order_attrs.get(TAG_CLORDID)
  assert replace_execution_report.get(TAG_EXECID) is not None
  assert replace_execution_report.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert replace_execution_report.get(TAG_EXECTYPE) == EXECTYPE_REPLACE
  assert replace_execution_report.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert replace_execution_report.get(
      TAG_SYMBOL) == replace_order_attrs.get(TAG_SYMBOL)
  assert replace_execution_report.get(
      TAG_SIDE) == replace_order_attrs.get(TAG_SIDE)
  assert float(replace_execution_report.get(
      TAG_ORDERQTY)) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_PRICE)
               ) == replace_order_attrs.get(TAG_PRICE)
  assert float(replace_execution_report.get(TAG_LASTQTY)
               ) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_LASTPX)
               ) <= replace_order_attrs.get(TAG_PRICE)
  assert float(replace_execution_report.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(replace_execution_report.get(TAG_CUMQTY)
               ) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_AVGPX)
               ) <= replace_order_attrs.get(TAG_PRICE)

  # Client B should receive partial fill execution report
  encoded_execution_report_2_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_2_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_2_client_b_msg)
  execution_report_2_client_b_msg = parser.get_message()
  assert execution_report_2_client_b_msg is not None
  validate_fix_message_header(
      execution_report_2_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 3)
  assert execution_report_2_client_b_msg.get(
      TAG_ORDERID) == execution_report_client_b_msg.get(TAG_ORDERID)
  assert execution_report_2_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_2_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTYPE) == EXECTYPE_PARTIAL_FILL
  assert execution_report_2_client_b_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_PARTIALLY_FILLED
  assert execution_report_2_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_2_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTQTY)
               ) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTPX)
               ) >= client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_LEAVES_QTY)) == (client_b_order_attrs.get(TAG_ORDERQTY) - replace_order_attrs.get(TAG_ORDERQTY))
  assert float(execution_report_2_client_b_msg.get(TAG_CUMQTY)
               ) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_AVGPX)
               ) >= order_attrs.get(TAG_PRICE)

  client_a.close()
  client_b.close()


# 2 clients submit orders that fully match AFTER client A increases his buy price
def test_two_clients_full_fill_after_replace_order():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new SELL order (should NOT match)
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 1500.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous order's price does not match
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)) == 0.0

  # Client A submits replace request increasing buy price + increasing quantity (should get fully filled)
  replace_order_attrs = {
      TAG_ORIGCLORDID: order_attrs.get(TAG_CLORDID),
      TAG_CLORDID: b'CLIA-1-Replaced',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 1500.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.25
  }
  replace_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST, client_a_comp_id, 3)
  for tag, value in replace_order_attrs.items():
    replace_order_msg.append_pair(tag, value)
  encoded_replace_order_msg = replace_order_msg.encode()

  client_a.sendall(encoded_replace_order_msg)
  encoded_replace_er_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_replace_er_msg != b''
  parser.reset()
  parser.append_buffer(encoded_replace_er_msg)
  replace_execution_report = parser.get_message()
  assert replace_execution_report is not None
  validate_fix_message_header(
      replace_execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert replace_execution_report.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert replace_execution_report.get(
      TAG_ORIGCLORDID) == replace_order_attrs.get(TAG_ORIGCLORDID)
  assert replace_execution_report.get(
      TAG_CLORDID) == replace_order_attrs.get(TAG_CLORDID)
  assert replace_execution_report.get(TAG_EXECID) is not None
  assert replace_execution_report.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert replace_execution_report.get(TAG_EXECTYPE) == EXECTYPE_REPLACE
  assert replace_execution_report.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert replace_execution_report.get(
      TAG_SYMBOL) == replace_order_attrs.get(TAG_SYMBOL)
  assert replace_execution_report.get(
      TAG_SIDE) == replace_order_attrs.get(TAG_SIDE)
  assert float(replace_execution_report.get(
      TAG_ORDERQTY)) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_PRICE)
               ) == replace_order_attrs.get(TAG_PRICE)
  assert float(replace_execution_report.get(TAG_LASTQTY)
               ) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_LASTPX)
               ) <= replace_order_attrs.get(TAG_PRICE)
  assert float(replace_execution_report.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(replace_execution_report.get(TAG_CUMQTY)
               ) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_AVGPX)
               ) <= replace_order_attrs.get(TAG_PRICE)

  # Client B should receive full fill execution report
  encoded_execution_report_2_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_2_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_2_client_b_msg)
  execution_report_2_client_b_msg = parser.get_message()
  assert execution_report_2_client_b_msg is not None
  validate_fix_message_header(
      execution_report_2_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 3)
  assert execution_report_2_client_b_msg.get(
      TAG_ORDERID) == execution_report_client_b_msg.get(TAG_ORDERID)
  assert execution_report_2_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_2_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTYPE) == EXECTYPE_FILL
  assert execution_report_2_client_b_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_2_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_2_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTPX)
               ) >= client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_2_client_b_msg.get(TAG_CUMQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_AVGPX)
               ) >= order_attrs.get(TAG_PRICE)

  client_a.close()
  client_b.close()


# Two unmatched orders are submitted. One is cancelled then other is modified. No matches should happen
def test_two_clients_replace_and_cancel_requests():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new SELL order (should NOT match)
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 1500.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous order's price does not match
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)) == 0.0

  # Cancel entire order
  cancel_order_attrs = {
      TAG_ORIGCLORDID: client_b_order_attrs.get(TAG_CLORDID),
      TAG_CLORDID: b'CLIB-1-Cancelled',
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
  }
  cancel_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REQUEST, client_b_comp_id, 3)
  for tag, value in cancel_order_attrs.items():
    cancel_order_msg.append_pair(tag, value)
  encoded_cancel_order_msg = cancel_order_msg.encode()

  client_b.sendall(encoded_cancel_order_msg)
  encoded_cancel_er_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_cancel_er_msg != b''
  parser.reset()
  parser.append_buffer(encoded_cancel_er_msg)
  cancel_execution_report = parser.get_message()
  assert cancel_execution_report is not None
  validate_fix_message_header(
      cancel_execution_report, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 3)
  assert cancel_execution_report.get(
      TAG_ORDERID) == execution_report_client_b_msg.get(TAG_ORDERID)
  assert cancel_execution_report.get(
      TAG_ORIGCLORDID) == cancel_order_attrs.get(TAG_ORIGCLORDID)
  assert cancel_execution_report.get(
      TAG_CLORDID) == cancel_order_attrs.get(TAG_CLORDID)
  assert cancel_execution_report.get(TAG_EXECID) is not None
  assert cancel_execution_report.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert cancel_execution_report.get(TAG_EXECTYPE) == EXECTYPE_CANCELED
  assert cancel_execution_report.get(TAG_ORDSTATUS) == ORDSTATUS_CANCELED
  assert cancel_execution_report.get(
      TAG_SYMBOL) == cancel_order_attrs.get(TAG_SYMBOL)
  assert cancel_execution_report.get(
      TAG_SIDE) == cancel_order_attrs.get(TAG_SIDE)
  assert float(cancel_execution_report.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(cancel_execution_report.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(cancel_execution_report.get(TAG_LASTQTY)) == 0.0
  assert float(cancel_execution_report.get(TAG_LASTPX)) == 0.0
  assert float(cancel_execution_report.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(cancel_execution_report.get(TAG_CUMQTY)) == 0.0
  assert float(cancel_execution_report.get(TAG_AVGPX)) == 0.0

  client_b.close()

  # Client A submits replace request increasing buy price + lowering quantity (should NOT match)
  replace_order_attrs = {
      TAG_ORIGCLORDID: order_attrs.get(TAG_CLORDID),
      TAG_CLORDID: b'CLIA-1-Replaced',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 75.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.25
  }
  replace_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST, client_a_comp_id, 3)
  for tag, value in replace_order_attrs.items():
    replace_order_msg.append_pair(tag, value)
  encoded_replace_order_msg = replace_order_msg.encode()

  client_a.sendall(encoded_replace_order_msg)
  encoded_replace_er_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_replace_er_msg != b''
  parser.reset()
  parser.append_buffer(encoded_replace_er_msg)
  replace_execution_report = parser.get_message()
  assert replace_execution_report is not None
  validate_fix_message_header(
      replace_execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert replace_execution_report.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert replace_execution_report.get(
      TAG_ORIGCLORDID) == replace_order_attrs.get(TAG_ORIGCLORDID)
  assert replace_execution_report.get(
      TAG_CLORDID) == replace_order_attrs.get(TAG_CLORDID)
  assert replace_execution_report.get(TAG_EXECID) is not None
  assert replace_execution_report.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert replace_execution_report.get(TAG_EXECTYPE) == EXECTYPE_REPLACE
  assert replace_execution_report.get(TAG_ORDSTATUS) == ORDSTATUS_REPLACED
  assert replace_execution_report.get(
      TAG_SYMBOL) == replace_order_attrs.get(TAG_SYMBOL)
  assert replace_execution_report.get(
      TAG_SIDE) == replace_order_attrs.get(TAG_SIDE)
  assert float(replace_execution_report.get(
      TAG_ORDERQTY)) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_PRICE)
               ) == replace_order_attrs.get(TAG_PRICE)
  assert float(replace_execution_report.get(TAG_LASTQTY)
               ) == 0.0
  assert float(replace_execution_report.get(TAG_LASTPX)
               ) == 0.0
  assert float(replace_execution_report.get(
      TAG_LEAVES_QTY)) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_CUMQTY)
               ) == 0.0
  assert float(replace_execution_report.get(TAG_AVGPX)
               ) == 0.0

  client_a.close()

# 1 client submits BUY order. Another submits SELL order. Both get fully filled. Cancel request is then submitted and rejected
def test_two_clients_full_fills_then_cancel():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B submits new SELL order (should match)
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 123.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be fully filled
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)
               ) >= client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)
               ) >= client_b_order_attrs.get(TAG_PRICE)

  # Client A should receive fill execution report
  encoded_execution_report_client_a_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_a_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_a_msg)
  execution_report_client_a_msg = parser.get_message()
  assert execution_report_client_a_msg is not None
  validate_fix_message_header(
      execution_report_client_a_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert execution_report_client_a_msg.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert execution_report_client_a_msg.get(
      TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_client_a_msg.get(TAG_EXECID) is not None
  assert execution_report_client_a_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_client_a_msg.get(TAG_EXECTYPE) == EXECTYPE_FILL
  assert execution_report_client_a_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_client_a_msg.get(
      TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_a_msg.get(
      TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_a_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_a_msg.get(TAG_LASTQTY)
               ) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_LASTPX)
               ) <= order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_a_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_client_a_msg.get(TAG_CUMQTY)
               ) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_a_msg.get(TAG_AVGPX)
               ) <= order_attrs.get(TAG_PRICE)

  client_a.close()

  # Client B tries to cancel an already filled order
  cancel_order_attrs = {
      TAG_ORIGCLORDID: client_b_order_attrs.get(TAG_CLORDID),
      TAG_CLORDID: b'CLIB-1-Cancelled',
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
  }
  cancel_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REQUEST, client_b_comp_id, 3)
  for tag, value in cancel_order_attrs.items():
    cancel_order_msg.append_pair(tag, value)
  encoded_cancel_order_msg = cancel_order_msg.encode()

  client_b.sendall(encoded_cancel_order_msg)
  encoded_order_cancel_reject_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_order_cancel_reject_msg != b''
  parser.reset()
  parser.append_buffer(encoded_order_cancel_reject_msg)
  order_cancel_reject_msg = parser.get_message()
  assert order_cancel_reject_msg is not None
  validate_fix_message_header(
      order_cancel_reject_msg, MSGTYPE_ORDER_CANCEL_REJECT, client_b_comp_id, 3)
  assert order_cancel_reject_msg.get(
      TAG_ORDERID) == execution_report_client_b_msg.get(TAG_ORDERID)
  assert order_cancel_reject_msg.get(
      TAG_ORIGCLORDID) == cancel_order_attrs.get(TAG_ORIGCLORDID)
  assert order_cancel_reject_msg.get(
      TAG_CLORDID) == cancel_order_attrs.get(TAG_CLORDID)
  assert order_cancel_reject_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert order_cancel_reject_msg.get(
      TAG_CXLREJRESPONSETO) == REJ_RESPONSE_TO_ORD_CANCEL_REQUEST
  assert order_cancel_reject_msg.get(
      TAG_CXLREJREASON) == CXLREJREASON_TOO_LATE_TO_CANCEL

  client_b.close()

# Four orders are submitted. 1st three initially don't match. The last one matches with 2 orders and gets fully filled
def test_four_clients_multiple_matches_for_one_order():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new BUY order
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 23,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 129.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous order was also a BUY order
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)) == 0.0

  # Client C Logon
  client_c_comp_id = b'CLIC'
  client_c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_c.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_c_logon_msg = get_encoded_logon_message(client_c_comp_id)

  client_c.sendall(client_c_logon_msg)
  encoded_logon_client_c_ack_msg = client_c.recv(BUFFER_SIZE)
  assert encoded_logon_client_c_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_c_ack_msg)
  client_c_logon_ack_msg = parser.get_message()
  assert client_c_logon_ack_msg is not None
  validate_fix_message_header(
      client_c_logon_ack_msg, MSGTYPE_LOGON, client_c_comp_id, 1)

  # Client C submits new SELL order (should NOT match)
  client_c_order_attrs = {
      TAG_CLORDID: b'CLIC-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 1500.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 192.46
  }
  new_order_single_client_c_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_c_comp_id, 2)
  for tag, value in client_c_order_attrs.items():
    new_order_single_client_c_msg.append_pair(tag, value)

  client_c.sendall(new_order_single_client_c_msg.encode())
  encoded_execution_report_client_c_msg = client_c.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_c_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_c_msg)
  execution_report_client_c_msg = parser.get_message()
  assert execution_report_client_c_msg is not None
  validate_fix_message_header(
      execution_report_client_c_msg, MSGTYPE_EXECUTION_REPORT, client_c_comp_id, 2)
  assert execution_report_client_c_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_c_msg.get(
      TAG_CLORDID) == client_c_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_c_msg.get(TAG_EXECID) is not None
  assert execution_report_client_c_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous orders' price does not match
  assert execution_report_client_c_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_c_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_c_msg.get(
      TAG_SYMBOL) == client_c_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_c_msg.get(
      TAG_SIDE) == client_c_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_c_msg.get(
      TAG_ORDERQTY)) == client_c_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_c_msg.get(TAG_PRICE)
               ) == client_c_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_c_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_c_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_c_msg.get(
      TAG_LEAVES_QTY)) == client_c_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_c_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_c_msg.get(TAG_AVGPX)) == 0.0

  client_c.close()

  # Client D Logon
  client_d_comp_id = b'CLID'
  client_d = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_d.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_d_logon_msg = get_encoded_logon_message(client_d_comp_id)

  client_d.sendall(client_d_logon_msg)
  encoded_logon_client_d_ack_msg = client_d.recv(BUFFER_SIZE)
  assert encoded_logon_client_d_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_d_ack_msg)
  client_d_logon_ack_msg = parser.get_message()
  assert client_d_logon_ack_msg is not None
  validate_fix_message_header(
      client_d_logon_ack_msg, MSGTYPE_LOGON, client_d_comp_id, 1)

  # Client D submits new SELL order (should get fully filled)
  client_d_order_attrs = {
      TAG_CLORDID: b'CLID-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 50.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.45
  }
  new_order_single_client_d_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_d_comp_id, 2)
  for tag, value in client_d_order_attrs.items():
    new_order_single_client_d_msg.append_pair(tag, value)

  client_d.sendall(new_order_single_client_d_msg.encode())
  encoded_execution_report_client_d_msg = client_d.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_d_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_d_msg)
  execution_report_client_d_msg = parser.get_message()
  assert execution_report_client_d_msg is not None
  validate_fix_message_header(
      execution_report_client_d_msg, MSGTYPE_EXECUTION_REPORT, client_d_comp_id, 2)
  assert execution_report_client_d_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_d_msg.get(
      TAG_CLORDID) == client_d_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_d_msg.get(TAG_EXECID) is not None
  assert execution_report_client_d_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be fully filled
  assert execution_report_client_d_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_d_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_client_d_msg.get(
      TAG_SYMBOL) == client_d_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_d_msg.get(
      TAG_SIDE) == client_d_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_d_msg.get(
      TAG_ORDERQTY)) == client_d_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_d_msg.get(TAG_PRICE)
               ) == client_d_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_d_msg.get(TAG_LASTQTY)
               ) == client_d_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_d_msg.get(TAG_LASTPX)
               ) >= client_d_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_d_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_client_d_msg.get(TAG_CUMQTY)
               ) == client_d_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_d_msg.get(TAG_AVGPX)
               ) >= client_d_order_attrs.get(TAG_PRICE)

  client_d.close()

  # Client B should receive full fill execution report
  encoded_execution_report_2_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_2_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_2_client_b_msg)
  execution_report_2_client_b_msg = parser.get_message()
  assert execution_report_2_client_b_msg is not None
  validate_fix_message_header(
      execution_report_2_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 3)
  assert execution_report_2_client_b_msg.get(
      TAG_ORDERID) == execution_report_client_b_msg.get(TAG_ORDERID)
  assert execution_report_2_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_2_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTYPE) == EXECTYPE_FILL
  assert execution_report_2_client_b_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_2_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_2_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTPX)
               ) <= client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_2_client_b_msg.get(TAG_CUMQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_AVGPX)
               ) <= client_b_order_attrs.get(TAG_PRICE)

  # Client A should receive partial fill execution report
  encoded_execution_report_2_client_a_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_2_client_a_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_2_client_a_msg)
  execution_report_2_client_a_msg = parser.get_message()
  assert execution_report_2_client_a_msg is not None
  validate_fix_message_header(
      execution_report_2_client_a_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert execution_report_2_client_a_msg.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert execution_report_2_client_a_msg.get(
      TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_2_client_a_msg.get(TAG_EXECID) is not None
  assert execution_report_2_client_a_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_2_client_a_msg.get(
      TAG_EXECTYPE) == EXECTYPE_PARTIAL_FILL
  assert execution_report_2_client_a_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_PARTIALLY_FILLED
  assert execution_report_2_client_a_msg.get(
      TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_2_client_a_msg.get(
      TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_2_client_a_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_a_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_a_msg.get(TAG_LASTQTY)
               ) == (client_d_order_attrs.get(TAG_ORDERQTY) - client_b_order_attrs.get(TAG_ORDERQTY))
  assert float(execution_report_2_client_a_msg.get(TAG_LASTPX)
               ) <= order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_a_msg.get(
      TAG_LEAVES_QTY)) == (order_attrs.get(TAG_ORDERQTY) - (client_d_order_attrs.get(TAG_ORDERQTY) - client_b_order_attrs.get(TAG_ORDERQTY)))
  assert float(execution_report_2_client_a_msg.get(TAG_CUMQTY)
               ) == (client_d_order_attrs.get(TAG_ORDERQTY) - client_b_order_attrs.get(TAG_ORDERQTY))
  assert float(execution_report_2_client_a_msg.get(TAG_AVGPX)
               ) <= order_attrs.get(TAG_PRICE)

  client_a.close()
  client_b.close()

# Four orders are submitted. 3rd (full fill) matches with 1st (partial fill). 4th (partial fill) matches with 1st and 2nd (both full fill)
def test_four_clients_filled_over_time():
  # Client A Logon
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  # Client A submits new BUY order
  order_attrs = {
      TAG_CLORDID: b'CLIA-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  # Client B Logon
  client_b_comp_id = b'CLIB'
  client_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_b.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_b_logon_msg = get_encoded_logon_message(client_b_comp_id)

  client_b.sendall(client_b_logon_msg)
  encoded_logon_client_b_ack_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_logon_client_b_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_b_ack_msg)
  client_b_logon_ack_msg = parser.get_message()
  assert client_b_logon_ack_msg is not None
  validate_fix_message_header(
      client_b_logon_ack_msg, MSGTYPE_LOGON, client_b_comp_id, 1)

  # Client B submits new BUY order
  client_b_order_attrs = {
      TAG_CLORDID: b'CLIB-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 23.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 124.2
  }
  new_order_single_client_b_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_b_comp_id, 2)
  for tag, value in client_b_order_attrs.items():
    new_order_single_client_b_msg.append_pair(tag, value)

  client_b.sendall(new_order_single_client_b_msg.encode())
  encoded_execution_report_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_b_msg)
  execution_report_client_b_msg = parser.get_message()
  assert execution_report_client_b_msg is not None
  validate_fix_message_header(
      execution_report_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 2)
  assert execution_report_client_b_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since the previous order was also a BUY order
  assert execution_report_client_b_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_b_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_client_b_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_client_b_msg.get(
      TAG_LEAVES_QTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_b_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_client_b_msg.get(TAG_AVGPX)) == 0.0

  # Client C Logon
  client_c_comp_id = b'CLIC'
  client_c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_c.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_c_logon_msg = get_encoded_logon_message(client_c_comp_id)

  client_c.sendall(client_c_logon_msg)
  encoded_logon_client_c_ack_msg = client_c.recv(BUFFER_SIZE)
  assert encoded_logon_client_c_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_c_ack_msg)
  client_c_logon_ack_msg = parser.get_message()
  assert client_c_logon_ack_msg is not None
  validate_fix_message_header(
      client_c_logon_ack_msg, MSGTYPE_LOGON, client_c_comp_id, 1)

  # Client C submits new SELL order (should get fully filled)
  client_c_order_attrs = {
      TAG_CLORDID: b'CLIC-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 12.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 124.9
  }
  new_order_single_client_c_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_c_comp_id, 2)
  for tag, value in client_c_order_attrs.items():
    new_order_single_client_c_msg.append_pair(tag, value)

  client_c.sendall(new_order_single_client_c_msg.encode())
  encoded_execution_report_client_c_msg = client_c.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_c_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_c_msg)
  execution_report_client_c_msg = parser.get_message()
  assert execution_report_client_c_msg is not None
  validate_fix_message_header(
      execution_report_client_c_msg, MSGTYPE_EXECUTION_REPORT, client_c_comp_id, 2)
  assert execution_report_client_c_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_c_msg.get(
      TAG_CLORDID) == client_c_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_c_msg.get(TAG_EXECID) is not None
  assert execution_report_client_c_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be fully filled
  assert execution_report_client_c_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_c_msg.get(TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_client_c_msg.get(
      TAG_SYMBOL) == client_c_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_c_msg.get(
      TAG_SIDE) == client_c_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_c_msg.get(
      TAG_ORDERQTY)) == client_c_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_c_msg.get(TAG_PRICE)
               ) == client_c_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_c_msg.get(TAG_LASTQTY)
               ) == client_c_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_c_msg.get(TAG_LASTPX)
               ) >= client_c_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_c_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_client_c_msg.get(TAG_CUMQTY)
               ) == client_c_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_c_msg.get(TAG_AVGPX)
               ) >= client_c_order_attrs.get(TAG_PRICE)

  # Client A should receive partial fill execution report
  client_a_expected_leaves_qty = (order_attrs.get(
      TAG_ORDERQTY) - client_c_order_attrs.get(TAG_ORDERQTY))
  encoded_execution_report_2_client_a_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_2_client_a_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_2_client_a_msg)
  execution_report_2_client_a_msg = parser.get_message()
  assert execution_report_2_client_a_msg is not None
  validate_fix_message_header(
      execution_report_2_client_a_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert execution_report_2_client_a_msg.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert execution_report_2_client_a_msg.get(
      TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_2_client_a_msg.get(TAG_EXECID) is not None
  assert execution_report_2_client_a_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_2_client_a_msg.get(
      TAG_EXECTYPE) == EXECTYPE_PARTIAL_FILL
  assert execution_report_2_client_a_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_PARTIALLY_FILLED
  assert execution_report_2_client_a_msg.get(
      TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_2_client_a_msg.get(
      TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_2_client_a_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_a_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_a_msg.get(TAG_LASTQTY)
               ) == client_c_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_a_msg.get(TAG_LASTPX)
               ) <= order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_a_msg.get(
      TAG_LEAVES_QTY)) == client_a_expected_leaves_qty
  assert float(execution_report_2_client_a_msg.get(TAG_CUMQTY)
               ) == client_c_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_a_msg.get(TAG_AVGPX)
               ) <= order_attrs.get(TAG_PRICE)

  # Client D Logon
  client_d_comp_id = b'CLID'
  client_d = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_d.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  client_d_logon_msg = get_encoded_logon_message(client_d_comp_id)

  client_d.sendall(client_d_logon_msg)
  encoded_logon_client_d_ack_msg = client_d.recv(BUFFER_SIZE)
  assert encoded_logon_client_d_ack_msg != b''

  parser.reset()
  parser.append_buffer(encoded_logon_client_d_ack_msg)
  client_d_logon_ack_msg = parser.get_message()
  assert client_d_logon_ack_msg is not None
  validate_fix_message_header(
      client_d_logon_ack_msg, MSGTYPE_LOGON, client_d_comp_id, 1)

  # Client D submits new SELL order (should get partially filled)
  client_d_order_attrs = {
      TAG_CLORDID: b'CLID-1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 500.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 124.1
  }
  new_order_single_client_d_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_d_comp_id, 2)
  for tag, value in client_d_order_attrs.items():
    new_order_single_client_d_msg.append_pair(tag, value)

  client_d.sendall(new_order_single_client_d_msg.encode())
  encoded_execution_report_client_d_msg = client_d.recv(BUFFER_SIZE)
  assert encoded_execution_report_client_d_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_client_d_msg)
  execution_report_client_d_msg = parser.get_message()
  assert execution_report_client_d_msg is not None
  validate_fix_message_header(
      execution_report_client_d_msg, MSGTYPE_EXECUTION_REPORT, client_d_comp_id, 2)
  assert execution_report_client_d_msg.get(TAG_ORDERID) is not None
  assert execution_report_client_d_msg.get(
      TAG_CLORDID) == client_d_order_attrs.get(TAG_CLORDID)
  assert execution_report_client_d_msg.get(TAG_EXECID) is not None
  assert execution_report_client_d_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be partially filled
  assert execution_report_client_d_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_client_d_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_PARTIALLY_FILLED
  assert execution_report_client_d_msg.get(
      TAG_SYMBOL) == client_d_order_attrs.get(TAG_SYMBOL)
  assert execution_report_client_d_msg.get(
      TAG_SIDE) == client_d_order_attrs.get(TAG_SIDE)
  assert float(execution_report_client_d_msg.get(
      TAG_ORDERQTY)) == client_d_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_client_d_msg.get(TAG_PRICE)
               ) == client_d_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_d_msg.get(TAG_LASTQTY)
               ) == (client_a_expected_leaves_qty + client_b_order_attrs.get(TAG_ORDERQTY))
  assert float(execution_report_client_d_msg.get(TAG_LASTPX)
               ) >= client_d_order_attrs.get(TAG_PRICE)
  assert float(execution_report_client_d_msg.get(
      TAG_LEAVES_QTY)) == (client_d_order_attrs.get(TAG_ORDERQTY) - client_a_expected_leaves_qty - client_b_order_attrs.get(TAG_ORDERQTY))
  assert float(execution_report_client_d_msg.get(TAG_CUMQTY)
               ) == (client_a_expected_leaves_qty + client_b_order_attrs.get(TAG_ORDERQTY))
  assert float(execution_report_client_d_msg.get(TAG_AVGPX)
               ) >= client_d_order_attrs.get(TAG_PRICE)

  # Client A should receive full fill execution report
  encoded_execution_report_3_client_a_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_3_client_a_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_3_client_a_msg)
  execution_report_3_client_a_msg = parser.get_message()
  assert execution_report_3_client_a_msg is not None
  validate_fix_message_header(
      execution_report_3_client_a_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 4)
  assert execution_report_3_client_a_msg.get(
      TAG_ORDERID) == execution_report_msg.get(TAG_ORDERID)
  assert execution_report_3_client_a_msg.get(
      TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_3_client_a_msg.get(TAG_EXECID) is not None
  assert execution_report_3_client_a_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_3_client_a_msg.get(
      TAG_EXECTYPE) == EXECTYPE_FILL
  assert execution_report_3_client_a_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_3_client_a_msg.get(
      TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_3_client_a_msg.get(
      TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_3_client_a_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_3_client_a_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(execution_report_3_client_a_msg.get(TAG_LASTQTY)
               ) == client_a_expected_leaves_qty
  assert float(execution_report_3_client_a_msg.get(TAG_LASTPX)
               ) <= order_attrs.get(TAG_PRICE)
  assert float(execution_report_3_client_a_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_3_client_a_msg.get(TAG_CUMQTY)
               ) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_3_client_a_msg.get(TAG_AVGPX)
               ) <= order_attrs.get(TAG_PRICE)

  # Client B should receive full fill execution report
  encoded_execution_report_2_client_b_msg = client_b.recv(BUFFER_SIZE)
  assert encoded_execution_report_2_client_b_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_2_client_b_msg)
  execution_report_2_client_b_msg = parser.get_message()
  assert execution_report_2_client_b_msg is not None
  validate_fix_message_header(
      execution_report_2_client_b_msg, MSGTYPE_EXECUTION_REPORT, client_b_comp_id, 3)
  assert execution_report_2_client_b_msg.get(
      TAG_ORDERID) == execution_report_client_b_msg.get(TAG_ORDERID)
  assert execution_report_2_client_b_msg.get(
      TAG_CLORDID) == client_b_order_attrs.get(TAG_CLORDID)
  assert execution_report_2_client_b_msg.get(TAG_EXECID) is not None
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_2_client_b_msg.get(
      TAG_EXECTYPE) == EXECTYPE_FILL
  assert execution_report_2_client_b_msg.get(
      TAG_ORDSTATUS) == ORDSTATUS_FILLED
  assert execution_report_2_client_b_msg.get(
      TAG_SYMBOL) == client_b_order_attrs.get(TAG_SYMBOL)
  assert execution_report_2_client_b_msg.get(
      TAG_SIDE) == client_b_order_attrs.get(TAG_SIDE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_ORDERQTY)) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_PRICE)
               ) == client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_LASTPX)
               ) <= client_b_order_attrs.get(TAG_PRICE)
  assert float(execution_report_2_client_b_msg.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(execution_report_2_client_b_msg.get(TAG_CUMQTY)
               ) == client_b_order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_client_b_msg.get(TAG_AVGPX)
               ) <= client_b_order_attrs.get(TAG_PRICE)

  client_a.close()
  client_b.close()
  client_c.close()
  client_d.close()
