from simplefix.constants import *
from simplefix.message import FixMessage

from src.common.constants import EXCHANGE_COMP_ID, FIX_BEGIN_STRING


def create_msg_with_header(msg_type: bytes, sender_comp_id: bytes, seq_num: int) -> FixMessage:
  msg = FixMessage()
  msg.append_pair(TAG_BEGINSTRING, FIX_BEGIN_STRING)
  msg.append_pair(TAG_MSGTYPE, msg_type)
  msg.append_pair(TAG_SENDER_COMPID, sender_comp_id)
  msg.append_pair(TAG_TARGET_COMPID, EXCHANGE_COMP_ID)
  msg.append_pair(TAG_MSGSEQNUM, seq_num)
  msg.append_utc_timestamp(TAG_SENDING_TIME, precision=6)
  return msg


def get_encoded_logon_message(sender_comp_id: bytes) -> bytes:
  logon_msg = create_msg_with_header(MSGTYPE_LOGON, sender_comp_id, 1)
  logon_msg.append_pair(TAG_HEARTBTINT, 30)
  logon_msg.append_pair(TAG_ENCRYPTMETHOD, ENCRYPTMETHOD_NONE)
  return (logon_msg.encode())


def validate_fix_message_header(msg: FixMessage, msg_type: bytes, client_id: bytes, expected_seq_num: int):
  assert msg.get(TAG_BEGINSTRING) == FIX_BEGIN_STRING
  assert msg.get(TAG_MSGTYPE) == msg_type
  assert msg.get(TAG_SENDER_COMPID) == EXCHANGE_COMP_ID
  assert msg.get(TAG_TARGET_COMPID) == client_id
  assert int(msg.get(TAG_MSGSEQNUM)) == expected_seq_num
  assert msg.get(TAG_BODYLENGTH) is not None
  assert msg.get(TAG_SENDING_TIME) is not None
