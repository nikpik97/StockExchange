import os
from multiprocessing import Process

import pytest
from dotenv import find_dotenv, load_dotenv

from src.gateway.server import GatewayServer
from src.matching_engine.server import MatchingEngineServer


@pytest.fixture(scope="package", autouse=True)
def load_environment_variables():
  load_dotenv(find_dotenv())


@pytest.fixture(scope="function", autouse=True)
def start_matching_engine(request):
  matching_engine_address = (
      os.getenv('MATCHING_ENGINE_HOST'), int(os.getenv('MATCHING_ENGINE_PORT')))
  matching_engine_server = MatchingEngineServer(matching_engine_address)
  process = Process(
      target=matching_engine_server.serve_forever)
  process.daemon = True
  process.start()
  request.addfinalizer(matching_engine_server.shutdown)
  request.addfinalizer(process.terminate)


@pytest.fixture(scope="function", autouse=True)
# Gateway will start after matching engine starts due to `start_matching_engine` dependency below
def start_gateway_server(request, start_matching_engine):
  gateway_address = (
      os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT')))
  gateway_server = GatewayServer(gateway_address)
  process = Process(target=gateway_server.serve_forever)
  process.daemon = True
  process.start()
  request.addfinalizer(gateway_server.shutdown)
  request.addfinalizer(process.terminate)
