import os
import socket
from datetime import datetime

from simplefix.constants import *
from simplefix.message import FixMessage
from simplefix.parser import FixParser

from src.common.constants import *

from .constants import *
from .utils import *

# TODO: Use timeouts + what if everything not sent in one go? + restart servers after each test case + assert already tested functionality?


def test_single_client_valid_order():
  client_a_comp_id = b'CLIA'
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''

  parser = FixParser()
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)
  assert logon_ack_msg.get(TAG_HEARTBTINT) == b'30'
  assert logon_ack_msg.get(TAG_ENCRYPTMETHOD) == ENCRYPTMETHOD_NONE

  order_attrs = {
      TAG_CLORDID: b'1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_single_msg.encode())
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report_msg = parser.get_message()
  assert execution_report_msg is not None
  validate_fix_message_header(
      execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_msg.get(TAG_ORDERID) is not None
  assert execution_report_msg.get(TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert execution_report_msg.get(TAG_EXECID) is not None
  assert execution_report_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # Order should be resting on order book since no other orders were submitted
  assert execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_msg.get(TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert execution_report_msg.get(TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_msg.get(TAG_AVGPX)) == 0.0

  client_a.close()


def test_single_client_duplicate_orders():
  client_a_comp_id = b'CLIA'
  parser = FixParser()
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  # Just perform header checks for Logon since it was verified in-depth in `test_single_client_valid_order`
  assert encoded_logon_ack_msg != b''
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  order_attrs = {
      TAG_CLORDID: b'1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)
  encoded_new_order_single_msg = new_order_single_msg.encode()

  client_a.sendall(encoded_new_order_single_msg)
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''
  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report = parser.get_message()
  assert execution_report is not None
  validate_fix_message_header(
      execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)

  # Send previously sent order again (should be rejected)
  dup_new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 3)
  for tag, value in order_attrs.items():
    dup_new_order_single_msg.append_pair(tag, value)
  encoded_dup_new_order_single_msg = dup_new_order_single_msg.encode()

  client_a.sendall(encoded_dup_new_order_single_msg)
  encoded_rejected_er_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_rejected_er_msg != b''

  parser.reset()
  parser.append_buffer(encoded_rejected_er_msg)
  rejected_execution_report_msg = parser.get_message()
  assert rejected_execution_report_msg is not None
  validate_fix_message_header(
      rejected_execution_report_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert rejected_execution_report_msg.get(
      TAG_ORDERID) == execution_report.get(TAG_ORDERID)
  assert rejected_execution_report_msg.get(
      TAG_CLORDID) == order_attrs.get(TAG_CLORDID)
  assert rejected_execution_report_msg.get(TAG_EXECID) is not None
  assert rejected_execution_report_msg.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  # ExecType should be rejected but order status should reflect current status on the order book
  assert rejected_execution_report_msg.get(TAG_EXECTYPE) == EXECTYPE_REJECTED
  assert rejected_execution_report_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert rejected_execution_report_msg.get(
      TAG_ORDERREJREASON) == ORDERREJREASON_DUPLICATE_ORDER
  assert rejected_execution_report_msg.get(
      TAG_SYMBOL) == order_attrs.get(TAG_SYMBOL)
  assert rejected_execution_report_msg.get(
      TAG_SIDE) == order_attrs.get(TAG_SIDE)
  assert float(rejected_execution_report_msg.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(rejected_execution_report_msg.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(rejected_execution_report_msg.get(TAG_LASTQTY)) == 0.0
  assert float(rejected_execution_report_msg.get(TAG_LASTPX)) == 0.0
  assert float(rejected_execution_report_msg.get(
      TAG_LEAVES_QTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(rejected_execution_report_msg.get(TAG_CUMQTY)) == 0.0
  assert float(rejected_execution_report_msg.get(TAG_AVGPX)) == 0.0

  client_a.close()


def test_single_client_replace_order():
  client_a_comp_id = b'CLIA'
  parser = FixParser()
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  order_attrs = {
      TAG_CLORDID: b'1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)
  encoded_new_order_single_msg = new_order_single_msg.encode()

  client_a.sendall(encoded_new_order_single_msg)
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''
  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report = parser.get_message()
  assert execution_report is not None
  validate_fix_message_header(
      execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)

  # Modify price and quantity
  replace_order_attrs = {
      TAG_ORIGCLORDID: b'1',
      TAG_CLORDID: b'replaced_1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 50.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 120.21
  }
  replace_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST, client_a_comp_id, 3)
  for tag, value in replace_order_attrs.items():
    replace_order_msg.append_pair(tag, value)
  encoded_replace_order_msg = replace_order_msg.encode()

  client_a.sendall(encoded_replace_order_msg)
  encoded_replace_er_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_replace_er_msg != b''
  parser.reset()
  parser.append_buffer(encoded_replace_er_msg)
  replace_execution_report = parser.get_message()
  assert replace_execution_report is not None
  validate_fix_message_header(
      replace_execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert replace_execution_report.get(
      TAG_ORDERID) == execution_report.get(TAG_ORDERID)
  assert replace_execution_report.get(
      TAG_ORIGCLORDID) == replace_order_attrs.get(TAG_ORIGCLORDID)
  assert replace_execution_report.get(
      TAG_CLORDID) == replace_order_attrs.get(TAG_CLORDID)
  assert replace_execution_report.get(TAG_EXECID) is not None
  assert replace_execution_report.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert replace_execution_report.get(TAG_EXECTYPE) == EXECTYPE_REPLACE
  assert replace_execution_report.get(TAG_ORDSTATUS) == ORDSTATUS_REPLACED
  assert replace_execution_report.get(
      TAG_SYMBOL) == replace_order_attrs.get(TAG_SYMBOL)
  assert replace_execution_report.get(
      TAG_SIDE) == replace_order_attrs.get(TAG_SIDE)
  assert float(replace_execution_report.get(
      TAG_ORDERQTY)) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_PRICE)
               ) == replace_order_attrs.get(TAG_PRICE)
  assert float(replace_execution_report.get(TAG_LASTQTY)) == 0.0
  assert float(replace_execution_report.get(TAG_LASTPX)) == 0.0
  assert float(replace_execution_report.get(
      TAG_LEAVES_QTY)) == replace_order_attrs.get(TAG_ORDERQTY)
  assert float(replace_execution_report.get(TAG_CUMQTY)) == 0.0
  assert float(replace_execution_report.get(TAG_AVGPX)) == 0.0

  client_a.close()


def test_single_client_invalid_replace_request():
  client_a_comp_id = b'CLIA'
  parser = FixParser()
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  order_attrs = {
      TAG_CLORDID: b'1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)
  encoded_new_order_single_msg = new_order_single_msg.encode()

  client_a.sendall(encoded_new_order_single_msg)
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''
  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report = parser.get_message()
  assert execution_report is not None
  validate_fix_message_header(
      execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)

  # Invalid replace request since updated side != original side
  invalid_replace_order_attrs = {
      TAG_ORIGCLORDID: b'1',
      TAG_CLORDID: b'replaced_1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_SELL,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 50.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 120.21
  }
  invalid_replace_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REPLACE_REQUEST, client_a_comp_id, 3)
  for tag, value in invalid_replace_order_attrs.items():
    invalid_replace_order_msg.append_pair(tag, value)
  encoded_invalid_replace_order_msg = invalid_replace_order_msg.encode()

  client_a.sendall(encoded_invalid_replace_order_msg)
  encoded_order_cancel_reject_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_order_cancel_reject_msg != b''
  parser.reset()
  parser.append_buffer(encoded_order_cancel_reject_msg)
  order_cancel_reject_msg = parser.get_message()
  assert order_cancel_reject_msg is not None
  validate_fix_message_header(
      order_cancel_reject_msg, MSGTYPE_ORDER_CANCEL_REJECT, client_a_comp_id, 3)
  assert order_cancel_reject_msg.get(
      TAG_ORDERID) == execution_report.get(TAG_ORDERID)
  assert order_cancel_reject_msg.get(
      TAG_ORIGCLORDID) == invalid_replace_order_attrs.get(TAG_ORIGCLORDID)
  assert order_cancel_reject_msg.get(
      TAG_CLORDID) == invalid_replace_order_attrs.get(TAG_CLORDID)
  assert order_cancel_reject_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert order_cancel_reject_msg.get(
      TAG_CXLREJRESPONSETO) == REJ_RESPONSE_TO_ORD_CANCEL_REPLACE_REQUEST
  assert order_cancel_reject_msg.get(
      TAG_CXLREJREASON) == CXLREJREASON_BROKER_OPTION

  client_a.close()


def test_single_client_cancel_order():
  client_a_comp_id = b'CLIA'
  parser = FixParser()
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  order_attrs = {
      TAG_CLORDID: b'1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)
  encoded_new_order_single_msg = new_order_single_msg.encode()

  client_a.sendall(encoded_new_order_single_msg)
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''
  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report = parser.get_message()
  assert execution_report is not None
  validate_fix_message_header(
      execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)

  # Cancel entire order
  cancel_order_attrs = {
      TAG_ORIGCLORDID: b'1',
      TAG_CLORDID: b'canceled_1',
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
  }
  cancel_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REQUEST, client_a_comp_id, 3)
  for tag, value in cancel_order_attrs.items():
    cancel_order_msg.append_pair(tag, value)
  encoded_cancel_order_msg = cancel_order_msg.encode()

  client_a.sendall(encoded_cancel_order_msg)
  encoded_cancel_er_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_cancel_er_msg != b''
  parser.reset()
  parser.append_buffer(encoded_cancel_er_msg)
  cancel_execution_report = parser.get_message()
  assert cancel_execution_report is not None
  validate_fix_message_header(
      cancel_execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert cancel_execution_report.get(
      TAG_ORDERID) == execution_report.get(TAG_ORDERID)
  assert cancel_execution_report.get(
      TAG_ORIGCLORDID) == cancel_order_attrs.get(TAG_ORIGCLORDID)
  assert cancel_execution_report.get(
      TAG_CLORDID) == cancel_order_attrs.get(TAG_CLORDID)
  assert cancel_execution_report.get(TAG_EXECID) is not None
  assert cancel_execution_report.get(
      TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert cancel_execution_report.get(TAG_EXECTYPE) == EXECTYPE_CANCELED
  assert cancel_execution_report.get(TAG_ORDSTATUS) == ORDSTATUS_CANCELED
  assert cancel_execution_report.get(
      TAG_SYMBOL) == cancel_order_attrs.get(TAG_SYMBOL)
  assert cancel_execution_report.get(
      TAG_SIDE) == cancel_order_attrs.get(TAG_SIDE)
  assert float(cancel_execution_report.get(
      TAG_ORDERQTY)) == order_attrs.get(TAG_ORDERQTY)
  assert float(cancel_execution_report.get(TAG_PRICE)
               ) == order_attrs.get(TAG_PRICE)
  assert float(cancel_execution_report.get(TAG_LASTQTY)) == 0.0
  assert float(cancel_execution_report.get(TAG_LASTPX)) == 0.0
  assert float(cancel_execution_report.get(
      TAG_LEAVES_QTY)) == 0.0
  assert float(cancel_execution_report.get(TAG_CUMQTY)) == 0.0
  assert float(cancel_execution_report.get(TAG_AVGPX)) == 0.0

  client_a.close()


def test_single_client_invalid_cancel_request():
  client_a_comp_id = b'CLIA'
  parser = FixParser()
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  order_attrs = {
      TAG_CLORDID: b'1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_attrs.items():
    new_order_single_msg.append_pair(tag, value)
  encoded_new_order_single_msg = new_order_single_msg.encode()

  client_a.sendall(encoded_new_order_single_msg)
  encoded_execution_report_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_msg != b''
  parser.reset()
  parser.append_buffer(encoded_execution_report_msg)
  execution_report = parser.get_message()
  assert execution_report is not None
  validate_fix_message_header(
      execution_report, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)

  # Invalid since order with client_id `unknown` should not exist
  invalid_cancel_order_attrs = {
      TAG_ORIGCLORDID: b'unknown',
      TAG_CLORDID: b'canceled',
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
  }
  invalid_cancel_order_msg = create_msg_with_header(
      MSGTYPE_ORDER_CANCEL_REQUEST, client_a_comp_id, 3)
  for tag, value in invalid_cancel_order_attrs.items():
    invalid_cancel_order_msg.append_pair(tag, value)
  encoded_invalid_cancel_order_msg = invalid_cancel_order_msg.encode()

  client_a.sendall(encoded_invalid_cancel_order_msg)
  encoded_order_cancel_reject_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_order_cancel_reject_msg != b''
  parser.reset()
  parser.append_buffer(encoded_order_cancel_reject_msg)
  order_cancel_reject_msg = parser.get_message()
  assert order_cancel_reject_msg is not None
  validate_fix_message_header(
      order_cancel_reject_msg, MSGTYPE_ORDER_CANCEL_REJECT, client_a_comp_id, 3)
  assert order_cancel_reject_msg.get(
      TAG_ORDERID) == b'NONE'
  assert order_cancel_reject_msg.get(
      TAG_ORIGCLORDID) == invalid_cancel_order_attrs.get(TAG_ORIGCLORDID)
  assert order_cancel_reject_msg.get(
      TAG_CLORDID) == invalid_cancel_order_attrs.get(TAG_CLORDID)
  assert order_cancel_reject_msg.get(TAG_ORDSTATUS) == ORDSTATUS_REJECTED
  assert order_cancel_reject_msg.get(
      TAG_CXLREJRESPONSETO) == REJ_RESPONSE_TO_ORD_CANCEL_REQUEST
  assert order_cancel_reject_msg.get(
      TAG_CXLREJREASON) == CXLREJREASON_UNKNOWN_ORDER

  client_a.close()


def test_single_client_multiple_orders():
  client_a_comp_id = b'CLIA'
  parser = FixParser()
  client_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  client_a.connect((os.getenv('GATEWAY_HOST'), int(os.getenv('GATEWAY_PORT'))))
  logon_msg = get_encoded_logon_message(client_a_comp_id)

  client_a.sendall(logon_msg)
  encoded_logon_ack_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_logon_ack_msg != b''
  parser.append_buffer(encoded_logon_ack_msg)
  logon_ack_msg = parser.get_message()
  assert logon_ack_msg is not None
  validate_fix_message_header(
      logon_ack_msg, MSGTYPE_LOGON, client_a_comp_id, 1)

  order_1_attrs = {
      TAG_CLORDID: b'1',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 100.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 125.5
  }
  new_order_1_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 2)
  for tag, value in order_1_attrs.items():
    new_order_1_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_1_single_msg.encode())
  encoded_execution_report_1_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_1_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_1_msg)
  execution_report_1_msg = parser.get_message()
  assert execution_report_1_msg is not None
  validate_fix_message_header(
      execution_report_1_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 2)
  assert execution_report_1_msg.get(TAG_ORDERID) is not None
  assert execution_report_1_msg.get(
      TAG_CLORDID) == order_1_attrs.get(TAG_CLORDID)
  assert execution_report_1_msg.get(TAG_EXECID) is not None
  assert execution_report_1_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_1_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_1_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_1_msg.get(
      TAG_SYMBOL) == order_1_attrs.get(TAG_SYMBOL)
  assert execution_report_1_msg.get(TAG_SIDE) == order_1_attrs.get(TAG_SIDE)
  assert float(execution_report_1_msg.get(
      TAG_ORDERQTY)) == order_1_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_1_msg.get(TAG_PRICE)
               ) == order_1_attrs.get(TAG_PRICE)
  assert float(execution_report_1_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_1_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_1_msg.get(
      TAG_LEAVES_QTY)) == order_1_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_1_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_1_msg.get(TAG_AVGPX)) == 0.0

  order_2_attrs = {
      TAG_CLORDID: b'2',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'FB',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 76.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 181.49
  }
  new_order_2_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 3)
  for tag, value in order_2_attrs.items():
    new_order_2_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_2_single_msg.encode())
  encoded_execution_report_2_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_2_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_2_msg)
  execution_report_2_msg = parser.get_message()
  assert execution_report_2_msg is not None
  validate_fix_message_header(
      execution_report_2_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 3)
  assert execution_report_2_msg.get(TAG_ORDERID) is not None
  assert execution_report_2_msg.get(
      TAG_CLORDID) == order_2_attrs.get(TAG_CLORDID)
  assert execution_report_2_msg.get(TAG_EXECID) is not None
  assert execution_report_2_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_2_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_2_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_2_msg.get(
      TAG_SYMBOL) == order_2_attrs.get(TAG_SYMBOL)
  assert execution_report_2_msg.get(TAG_SIDE) == order_2_attrs.get(TAG_SIDE)
  assert float(execution_report_2_msg.get(
      TAG_ORDERQTY)) == order_2_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_msg.get(TAG_PRICE)
               ) == order_2_attrs.get(TAG_PRICE)
  assert float(execution_report_2_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_2_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_2_msg.get(
      TAG_LEAVES_QTY)) == order_2_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_2_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_2_msg.get(TAG_AVGPX)) == 0.0

  order_3_attrs = {
      TAG_CLORDID: b'3',
      TAG_HANDLINST: HANDLINST_AUTO_PRIVATE,
      TAG_SYMBOL: b'MSFT',
      TAG_SIDE: SIDE_BUY,
      TAG_TRANSACTTIME: datetime.utcnow().strftime(TIMESTAMP_FORMAT),
      TAG_ORDERQTY: 24.0,
      TAG_ORDTYPE: ORDTYPE_LIMIT,
      TAG_PRICE: 127.92
  }
  new_order_3_single_msg = create_msg_with_header(
      MSGTYPE_NEW_ORDER_SINGLE, client_a_comp_id, 4)
  for tag, value in order_3_attrs.items():
    new_order_3_single_msg.append_pair(tag, value)

  client_a.sendall(new_order_3_single_msg.encode())
  encoded_execution_report_3_msg = client_a.recv(BUFFER_SIZE)
  assert encoded_execution_report_3_msg != b''

  parser.reset()
  parser.append_buffer(encoded_execution_report_3_msg)
  execution_report_3_msg = parser.get_message()
  assert execution_report_3_msg is not None
  validate_fix_message_header(
      execution_report_3_msg, MSGTYPE_EXECUTION_REPORT, client_a_comp_id, 4)
  assert execution_report_3_msg.get(TAG_ORDERID) is not None
  assert execution_report_3_msg.get(
      TAG_CLORDID) == order_3_attrs.get(TAG_CLORDID)
  assert execution_report_3_msg.get(TAG_EXECID) is not None
  assert execution_report_3_msg.get(TAG_EXECTRANSTYPE) == EXECTRANSTYPE_NEW
  assert execution_report_3_msg.get(TAG_EXECTYPE) == EXECTYPE_NEW
  assert execution_report_3_msg.get(TAG_ORDSTATUS) == ORDSTATUS_NEW
  assert execution_report_3_msg.get(
      TAG_SYMBOL) == order_3_attrs.get(TAG_SYMBOL)
  assert execution_report_3_msg.get(TAG_SIDE) == order_3_attrs.get(TAG_SIDE)
  assert float(execution_report_3_msg.get(
      TAG_ORDERQTY)) == order_3_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_3_msg.get(TAG_PRICE)
               ) == order_3_attrs.get(TAG_PRICE)
  # Verify that execution report is for a non-fill
  assert float(execution_report_3_msg.get(TAG_LASTQTY)) == 0.0
  assert float(execution_report_3_msg.get(TAG_LASTPX)) == 0.0
  assert float(execution_report_3_msg.get(
      TAG_LEAVES_QTY)) == order_3_attrs.get(TAG_ORDERQTY)
  assert float(execution_report_3_msg.get(TAG_CUMQTY)) == 0.0
  assert float(execution_report_3_msg.get(TAG_AVGPX)) == 0.0

  client_a.close()
